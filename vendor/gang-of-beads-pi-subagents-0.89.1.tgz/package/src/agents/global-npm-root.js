import { exec, execFile } from "node:child_process";
import { promises as fs } from "node:fs";
import path from "node:path";
/** Optional global package discovery; a failure never prevents local discovery. */
export async function resolveGlobalNpmRoot(options = {}) {
    const signal = options.signal;
    if (signal?.aborted)
        return null;
    const env = options.env ?? process.env;
    const offline = env.PI_OFFLINE?.toLowerCase();
    if (offline === "1" || offline === "true" || offline === "yes")
        return null;
    if ((options.platform ?? process.platform) === "win32" && env.APPDATA) {
        const appDataRoot = path.join(env.APPDATA, "npm", "node_modules");
        try {
            if ((await fs.stat(appDataRoot)).isDirectory())
                return await fs.realpath(appDataRoot);
        }
        catch {
            // Invalid APPDATA roots fall back to npm (including disappearing directories).
        }
    }
    if (signal?.aborted)
        return null;
    const timeoutMs = options.timeoutMs ?? 5000;
    const output = await new Promise((resolve) => {
        let settled = false;
        const finish = (value) => {
            if (settled)
                return;
            settled = true;
            clearTimeout(timer);
            signal?.removeEventListener("abort", cancel);
            resolve(value);
        };
        const commandOptions = {
            encoding: "utf8",
            timeout: timeoutMs,
            windowsHide: true,
            env,
            maxBuffer: 64 * 1024,
        };
        // POSIX npm is executable directly: killing a shell would leave npm running.
        // Windows npm.cmd requires a shell, matching the existing command behavior.
        const callback = (error, stdout) => finish(error ? null : stdout.trim());
        const child = (options.platform ?? process.platform) === "win32"
            ? exec("npm root -g", commandOptions, callback)
            : execFile("npm", ["root", "-g"], commandOptions, callback);
        const cancel = () => {
            child.kill();
            finish(null);
        };
        // Resolve at the deadline even if inherited pipes hold the callback open.
        const timer = setTimeout(cancel, timeoutMs);
        signal?.addEventListener("abort", cancel, { once: true });
    });
    if (!output)
        return null;
    try {
        return await fs.realpath(output);
    }
    catch {
        return null;
    }
}
