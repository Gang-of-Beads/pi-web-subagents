import { randomUUID } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { writeAtomicJson } from "../../shared/atomic-json.js";
import { readStatus } from "../../shared/utils.js";
import { deliverInterruptRequest, queueRevivalBrief, requestAsyncSteer } from "../background/control-channel.js";
import { resolveAsyncResumeTarget } from "../background/async-resume.js";
import { reconcileAsyncRun } from "../background/stale-run-reconciler.js";
import { actionResultFromSteeringStatus, claimSteeringRecovery, createSteeringStatus, recordSteeringRequest, remainingSteeringRecoveryLimits, steeringReceipt, updateSteeringTarget, waitForSteeringAction } from "../background/steering.js";
import { ownsRun } from "../shared/run-ownership.js";
function steerTargetsAccepted(result) {
    const targets = result?.targets ?? [];
    return targets.length > 0 && targets.every((target) => target.state === "queued" || target.state === "delivered");
}
function steerTargetsRejected(result) {
    return result?.targets.some((target) => target.state === "failed" && target.failureKind === "rejected") === true;
}
export function canQueueRetainedAsyncFollowUp(status, index) {
    const steps = status.steps ?? [];
    return status.state === "complete"
        && Boolean(status.parentWorkflowRunId)
        && steps.length === 1
        && (steps[0]?.status === "complete" || steps[0]?.status === "completed")
        && Boolean(steps[0]?.sessionFile ?? status.sessionFile)
        && (index === undefined || index === 0);
}
export async function steerAsyncRun(input) {
    if (!input.location.asyncDir) {
        return {
            content: [{ type: "text", text: `Async run '${input.runId}' has no live run directory to steer.` }],
            isError: true,
            details: { mode: "management", results: [] },
        };
    }
    const asyncDir = input.location.asyncDir;
    const snapshot = input.findPendingAsks ? readStatus(asyncDir) : null;
    if (snapshot?.mode === "single"
        && (!input.state.currentSessionId || ownsRun(input.state.currentSessionId, snapshot.sessionId))
        && (snapshot.state === "running" || snapshot.state === "queued")
        && snapshot.steps?.length === 1 && (input.index === undefined || input.index === 0)
        && (snapshot.steps[0]?.status === "running" || snapshot.steps[0]?.status === "pending")) {
        const asks = input.findPendingAsks?.({ runId: snapshot.runId, agent: snapshot.steps[0].agent, childIndex: 0 }) ?? [];
        if (asks.length > 0) {
            const replies = asks.map(replyTo => `subagent_supervisor(${JSON.stringify({ action: "reply", replyTo, message: "<explicit answer>" })})`).join("\n");
            return {
                content: [{ type: "text", text: `Steering not delivered or queued: async run ${snapshot.runId} is blocked on ${asks.length === 1 ? "a pending supervisor ask" : "ambiguous pending supervisor asks"}. No reply or recovery was attempted. Reply explicitly${asks.length > 1 ? " to the intended request ID" : ""}:\n${replies}` }],
                isError: true,
                details: { mode: "management", results: [] },
            };
        }
    }
    // The read-only snapshot precedes even stale-run reconciliation. An ask arriving
    // later does not make a runner acknowledgement proof of consumption or unblocking.
    const status = reconcileAsyncRun(asyncDir, { kill: input.kill }).status;
    if (input.state.currentSessionId && !ownsRun(input.state.currentSessionId, status?.sessionId)) {
        return {
            content: [{ type: "text", text: `Async run '${input.runId}' was not found in the active session.` }],
            isError: true,
            details: { mode: "management", results: [] },
        };
    }
    if (!status) {
        return {
            content: [{ type: "text", text: `Async run '${input.runId}' was not found.` }],
            isError: true,
            details: { mode: "management", results: [] },
        };
    }
    const steps = status.steps ?? [];
    if (status.state !== "running" && status.state !== "queued") {
        const followUpEligible = canQueueRetainedAsyncFollowUp(status, input.index);
        const retained = input.mode === "follow_up" && followUpEligible;
        if (!retained) {
            // Name the terminal state and the next action so a steer that lost a race with
            // completion does not look like a missing run. Mirrors the sibling nested/workflow errors.
            // Offer resume only when the resume action's own target checks accept the run (it resolves without
            // requiring a session file, as at subagent-executor's resume), and otherwise say why not.
            let resumeHint = `Continue it with action "resume", or read its saved result.`;
            try {
                resolveAsyncResumeTarget({ dir: asyncDir, index: input.index }, { kill: input.kill }, { requireSessionFile: false, sessionId: input.state.currentSessionId ?? undefined });
            }
            catch (error) {
                resumeHint = `action "resume" is not available either: ${error instanceof Error ? error.message : String(error)}`;
            }
            const hint = followUpEligible
                ? `Queue this message for its next resume with mode "follow_up", or continue the run now with action "resume".`
                : input.mode === "follow_up"
                    ? `mode "follow_up" requires a completed single-child workflow run with a persisted session. ${resumeHint}`
                    : resumeHint;
            return {
                content: [{ type: "text", text: `Async run '${input.runId}' is ${status.state} and cannot be steered; steering requires state "running" or "queued". ${hint}` }],
                isError: true,
                details: { mode: "management", results: [] },
            };
        }
        const request = { type: "steer", id: randomUUID(), ts: Date.now(), message: input.message.trim(), mode: "follow_up", targetIndex: 0, source: "steer-action" };
        try {
            queueRevivalBrief(asyncDir, request);
        }
        catch (error) {
            return { content: [{ type: "text", text: `Failed to queue retained follow-up for async run ${status.runId}: ${error instanceof Error ? error.message : String(error)}` }], isError: true, details: { mode: "management", results: [] } };
        }
        status.steering ??= createSteeringStatus();
        recordSteeringRequest(status.steering, { id: request.id, requestedAt: request.ts, source: request.source, message: request.message, targets: [{ index: 0, state: "scheduled" }] });
        writeAtomicJson(path.join(asyncDir, "status.json"), status);
        const queued = { requestId: request.id, state: "scheduled", deliveryStatus: "queued", sourceRunId: status.runId, targets: [{ index: 0, state: "scheduled" }] };
        return { content: [{ type: "text", text: steeringReceipt(request.message, `Follow-up queued for the next resume of retained async run ${status.runId} (request ${request.id}).`) }], details: { mode: "management", results: [], steering: queued } };
    }
    if (input.index !== undefined) {
        if (input.index < 0 || input.index >= steps.length) {
            return {
                content: [{ type: "text", text: `Async run '${status.runId}' has ${steps.length} children. Index ${input.index} is out of range.` }],
                isError: true,
                details: { mode: "management", results: [] },
            };
        }
        const targetStep = steps[input.index];
        if (targetStep && targetStep.status !== "running" && targetStep.status !== "pending") {
            return {
                content: [{ type: "text", text: `Async run '${status.runId}' child ${input.index} is ${targetStep.status} and cannot be steered.` }],
                isError: true,
                details: { mode: "management", results: [] },
            };
        }
    }
    else {
        const running = steps.filter((step) => step.status === "running");
        if (running.length === 0 && steps.length > 1) {
            return {
                content: [{ type: "text", text: `Async run '${status.runId}' has no running child yet. Provide index to steer a queued child.` }],
                isError: true,
                details: { mode: "management", results: [] },
            };
        }
    }
    const runningIndexes = steps
        .map((step, index) => step.status === "running" ? index : undefined)
        .filter((index) => index !== undefined);
    const effectiveTargetIndex = input.index ?? (status.mode === "single" && runningIndexes.length === 0 && steps[0]?.status === "pending" ? 0 : undefined);
    const targetIndexes = effectiveTargetIndex !== undefined ? [effectiveTargetIndex] : runningIndexes;
    if (targetIndexes.length === 0) {
        return {
            content: [{ type: "text", text: `Async run '${status.runId}' has no running child to steer.` }],
            isError: true,
            details: { mode: "management", results: [] },
        };
    }
    const requestId = randomUUID();
    let requestPath;
    try {
        requestPath = requestAsyncSteer(asyncDir, {
            message: input.message,
            mode: input.mode,
            ...(effectiveTargetIndex !== undefined ? { targetIndex: effectiveTargetIndex } : { targetIndexes }),
            source: "steer-action",
            id: requestId,
        });
    }
    catch (error) {
        return {
            content: [{ type: "text", text: `Failed to queue steering for async run ${status.runId}: ${error instanceof Error ? error.message : String(error)}` }],
            isError: true,
            details: { mode: "management", results: [] },
        };
    }
    input.onRequestQueued?.(requestPath);
    const tracked = input.state.asyncJobs.get(status.runId);
    if (tracked)
        tracked.updatedAt = Date.now();
    const targets = targetIndexes.map((index) => ({ index, state: status.steps?.[index]?.status === "pending" ? "scheduled" : "pending" }));
    if (targets.every((target) => target.state === "scheduled")) {
        const scheduled = { requestId, state: "scheduled", deliveryStatus: "queued", sourceRunId: status.runId, targets };
        return { content: [{ type: "text", text: steeringReceipt(input.message, `Steering scheduled for async run ${status.runId} (request ${requestId}).`) }], details: { mode: "management", results: [], steering: scheduled } };
    }
    const waited = await waitForSteeringAction({ asyncDir, sourceRunId: status.runId, requestId, timeoutMs: input.ackTimeoutMs ?? 3_000, signal: input.signal });
    const result = waited ?? { requestId, state: "pending", deliveryStatus: "queued", sourceRunId: status.runId, targets };
    if (input.signal?.aborted) {
        return { content: [{ type: "text", text: steeringReceipt(input.message, `Steering pending for async run ${status.runId} (request ${requestId}); caller aborted before recovery.`) }], details: { mode: "management", results: [], steering: result } };
    }
    const projected = (current) => current?.steering ? actionResultFromSteeringStatus(current.steering, status.runId, requestId) : undefined;
    const rejected = () => new Error(`Child rejected the guidance; continue it with action "resume" and id "${status.runId}".`);
    const finalStatus = readStatus(asyncDir);
    const finalResult = projected(finalStatus);
    const acceptedReply = (accepted) => {
        const acceptedState = accepted.state === "delivered" ? "delivered" : "queued";
        return { content: [{ type: "text", text: steeringReceipt(input.message, `Steering ${acceptedState} for async run ${status.runId} (request ${requestId}).`) }], details: { mode: "management", results: [], steering: accepted } };
    };
    if (finalResult && steerTargetsAccepted(finalResult))
        return acceptedReply(finalResult);
    const running = (finalStatus?.steps ?? status.steps ?? []).filter((step) => step.status === "running");
    const recoveryAllowed = (input.mode ?? "steer") === "steer" && status.mode === "single" && status.isNested !== true && running.length === 1 && Boolean(finalStatus?.steering) && (input.index === undefined || input.index === 0);
    if (recoveryAllowed && finalResult?.state !== "scheduled" && !steerTargetsRejected(finalResult) && input.recover) {
        const appendSteeringNotice = (state, message) => {
            try {
                fs.appendFileSync(path.join(asyncDir, "events.jsonl"), `${JSON.stringify({ type: "subagent.steering.notice", ts: Date.now(), runId: status.runId, requestId, state, message, ...(status.sessionId ? { currentSessionId: status.sessionId } : {}) })}\n`);
            }
            catch {
                // The action result and status remain authoritative if diagnostic notification persistence fails.
            }
        };
        try {
            const latestResult = projected(readStatus(asyncDir));
            if (latestResult && steerTargetsAccepted(latestResult))
                return acceptedReply(latestResult);
            if (steerTargetsRejected(latestResult))
                throw rejected();
            const committedAt = Date.now();
            input.onBeforeRecoveryClaim?.(requestId, committedAt);
            const { claimPath, markerPath } = claimSteeringRecovery(asyncDir, { requestId, sourceRunId: status.runId, committedAt });
            input.onRecoveryCommitted?.(requestId, committedAt);
            const preCommitResult = projected(readStatus(asyncDir));
            if (preCommitResult
                && (steerTargetsRejected(preCommitResult) || (preCommitResult.targets.length > 0
                    && preCommitResult.targets.every((target) => target.state === "queued" || (target.deliveredAt !== undefined && target.deliveredAt <= committedAt))))) {
                fs.rmSync(markerPath, { force: true });
                fs.rmSync(claimPath, { force: true });
                if (steerTargetsRejected(preCommitResult))
                    throw rejected();
                return acceptedReply(preCommitResult);
            }
            try {
                deliverInterruptRequest({ asyncDir, source: "steering-recovery" });
            }
            catch (error) {
                fs.rmSync(markerPath, { force: true });
                fs.rmSync(claimPath, { force: true });
                throw new Error(`Failed to commit steering recovery interrupt: ${error instanceof Error ? error.message : String(error)}`);
            }
            const pauseBudgetMs = input.recoveryTimeoutMs ?? 15_000;
            const pauseDeadline = Date.now() + pauseBudgetMs;
            let paused = null;
            let lastObservedState;
            while (Date.now() <= pauseDeadline) {
                if (input.signal?.aborted)
                    break;
                const candidate = readStatus(asyncDir);
                lastObservedState = candidate?.state;
                if (steerTargetsRejected(projected(candidate))) {
                    fs.rmSync(claimPath, { force: true });
                    throw rejected();
                }
                if (candidate?.state === "paused" && candidate.endedAt !== undefined) {
                    paused = candidate;
                    break;
                }
                await new Promise((resolve) => setTimeout(resolve, 50));
            }
            if (!paused) {
                // The attempt is over, so release single-flight for later steers. Keep the marker so a late
                // acknowledgment of this request is still recorded as late.
                fs.rmSync(claimPath, { force: true });
                throw new Error(`Source run did not confirm a paused state within ${pauseBudgetMs / 1000} seconds after the recovery interrupt (last observed state: ${lastObservedState ?? "unknown"}). No replacement was launched and the steering message was not applied. Once it pauses, continue it with action "resume" and id "${status.runId}".`);
            }
            let recoveryTarget;
            try {
                recoveryTarget = resolveAsyncResumeTarget({ id: status.runId }, { kill: input.kill }, { sessionId: input.state.currentSessionId ?? undefined });
            }
            catch (error) {
                throw new Error(`Source run remains paused and cannot be revived safely: ${error instanceof Error ? error.message : String(error)}`);
            }
            if (recoveryTarget.kind !== "revive" || !recoveryTarget.sessionFile)
                throw new Error("Source run has no valid persisted child session; it remains paused and requires a new run.");
            if (!recoveryTarget.recoveryDescriptor)
                throw new Error("Source run has no private recovery descriptor; it remains paused and is not safely resumable.");
            const limits = remainingSteeringRecoveryLimits(recoveryTarget.recoveryDescriptor, paused);
            if (steerTargetsRejected(projected(readStatus(asyncDir)))) {
                fs.rmSync(claimPath, { force: true });
                throw rejected();
            }
            const revived = await input.recover(limits);
            if (revived.isError || !revived.details.asyncId)
                throw new Error(revived.content[0]?.type === "text" ? revived.content[0].text : "Replacement launch failed; source run remains paused.");
            const targetIndex = input.index ?? paused.steering?.recent.find((request) => request.id === requestId)?.targets[0]?.index ?? status.steps?.findIndex((step) => step.status === "running") ?? -1;
            if (paused.steering && targetIndex >= 0) {
                updateSteeringTarget(paused.steering, requestId, targetIndex, "recovered", Date.now(), { replacementRunId: revived.details.asyncId });
                const stepSteering = paused.steps?.[targetIndex]?.steering;
                if (stepSteering)
                    updateSteeringTarget(stepSteering, requestId, targetIndex, "recovered", Date.now(), { replacementRunId: revived.details.asyncId });
                writeAtomicJson(path.join(asyncDir, "status.json"), paused);
            }
            const recovered = paused.steering ? actionResultFromSteeringStatus(paused.steering, status.runId, requestId, revived.details.asyncId) : undefined;
            appendSteeringNotice("recovered", `Steering recovered for run ${status.runId}; replacement ${revived.details.asyncId} launched.`);
            return { content: [{ type: "text", text: steeringReceipt(input.message, `Steering recovered for async run ${status.runId}; replacement ${revived.details.asyncId} launched after the source paused.`) }], details: { mode: "management", results: [], steering: recovered ?? { requestId, state: "recovered", sourceRunId: status.runId, replacementRunId: revived.details.asyncId, deliveryStatus: "delivered", targets: [{ index: input.index ?? 0, state: "recovered" }] } } };
        }
        catch (error) {
            const reason = error instanceof Error ? error.message : String(error);
            const failedStatus = readStatus(asyncDir);
            const targetIndex = input.index ?? status.steps?.findIndex((step) => step.status === "running") ?? -1;
            if (failedStatus && failedStatus.state !== "running" && failedStatus.state !== "queued" && failedStatus.steering && targetIndex >= 0) {
                updateSteeringTarget(failedStatus.steering, requestId, targetIndex, "failed", Date.now(), { reason });
                const stepSteering = failedStatus.steps?.[targetIndex]?.steering;
                if (stepSteering)
                    updateSteeringTarget(stepSteering, requestId, targetIndex, "failed", Date.now(), { reason });
                failedStatus.activityState = "needs_attention";
                writeAtomicJson(path.join(asyncDir, "status.json"), failedStatus);
            }
            const failed = projected(failedStatus);
            appendSteeringNotice("failed", `Steering failed for run ${status.runId}: ${reason}`);
            return { content: [{ type: "text", text: steeringReceipt(input.message, `Steering failed for async run ${status.runId} (request ${requestId}): ${reason}`) }], isError: true, details: { mode: "management", results: [], steering: failed ?? { requestId, state: "failed", sourceRunId: status.runId, deliveryStatus: "queued", targets: [{ index: input.index ?? 0, state: "failed", reason }] } } };
        }
    }
    const stateText = result.state === "failed" ? "failed" : result.state === "partial" ? "partial" : result.deliveryStatus === "queued" ? "queued" : result.state === "delivered" ? "delivered" : result.state === "scheduled" ? "scheduled" : result.state === "recovered" ? "recovered" : "pending";
    const isError = result.state === "failed" || result.state === "partial";
    return {
        content: [{ type: "text", text: steeringReceipt(input.message, `Steering ${stateText} for async run ${status.runId} (request ${requestId}).`) }],
        ...(isError ? { isError: true } : {}),
        details: { mode: "management", results: [], steering: result },
    };
}
