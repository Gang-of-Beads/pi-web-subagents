import { execFile, execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { promisify } from "node:util";
const MAX_TRACKED_PATHS = 500;
const MAX_HASH_BYTES = 1024 * 1024;
const MAX_TIMEOUT_FILES = 20;
function gitArguments(args) {
    // Mutation evidence must not block child startup on a stale fsmonitor daemon.
    return ["-c", "core.fsmonitor=false", ...args];
}
function gitOutput(cwd, args, maxBuffer = MAX_HASH_BYTES) {
    return execFileSync("git", gitArguments(args), { cwd, encoding: "utf-8", stdio: ["ignore", "pipe", "pipe"], maxBuffer, windowsHide: true });
}
const execFileAsync = promisify(execFile);
/** The collection path runs while sibling children settle, so git runs off the event loop. */
async function gitOutputAsync(cwd, args) {
    return (await execFileAsync("git", gitArguments(args), { cwd, encoding: "utf-8", maxBuffer: MAX_HASH_BYTES, windowsHide: true })).stdout;
}
/** Yields to the event loop every 2 MiB so hashing a large diff does not stall other work. */
async function hashFileAsync(diffPath) {
    const hash = createHash("sha256");
    const fd = fs.openSync(diffPath, "r");
    try {
        const buffer = Buffer.alloc(64 * 1024);
        let chunks = 0;
        for (;;) {
            const bytesRead = fs.readSync(fd, buffer, 0, buffer.length, null);
            if (bytesRead === 0)
                break;
            hash.update(bytesRead === buffer.length ? buffer : buffer.subarray(0, bytesRead));
            if (++chunks % 32 === 0)
                await new Promise((resolve) => setImmediate(resolve));
        }
    }
    finally {
        fs.closeSync(fd);
    }
    return hash.digest("hex");
}
function splitNul(output) {
    return output.split("\0").filter((part) => part.length > 0);
}
/** Git prints its whole option reference after the error, which must not reach recovery summaries. */
function gitFailureReason(error) {
    const stderr = error && typeof error === "object" && "stderr" in error ? String(error.stderr ?? "") : "";
    if (/not a git repository/i.test(stderr))
        return "not a Git work tree";
    const firstLine = (stderr || (error instanceof Error ? error.message : String(error))).split("\n").find((line) => line.trim().length > 0);
    return firstLine?.trim() ?? "git failed";
}
function hashLargeDiff(cwd, relativePath) {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "pi-subagents-tracked-diff-"));
    const diffPath = path.join(tempDir, "diff.patch");
    try {
        execFileSync("git", gitArguments(["diff", "--no-ext-diff", "--binary", `--output=${diffPath}`, "HEAD", "--", relativePath]), { cwd, stdio: "ignore", windowsHide: true });
        const hash = createHash("sha256");
        const buffer = Buffer.allocUnsafe(64 * 1024);
        const fd = fs.openSync(diffPath, "r");
        try {
            for (;;) {
                const bytesRead = fs.readSync(fd, buffer, 0, buffer.length, null);
                if (bytesRead === 0)
                    break;
                hash.update(buffer.subarray(0, bytesRead));
            }
        }
        finally {
            fs.closeSync(fd);
        }
        return hash.digest("hex");
    }
    finally {
        fs.rmSync(tempDir, { recursive: true, force: true });
    }
}
const CHANGED_FILES_ARGS = ["diff", "--no-ext-diff", "--name-only", "-z", "HEAD", "--"];
function changedTrackedFiles(nameOnlyOutput) {
    const paths = splitNul(nameOnlyOutput);
    return { paths: paths.slice(0, MAX_TRACKED_PATHS), truncated: paths.length > MAX_TRACKED_PATHS };
}
function fingerprintPath(cwd, relativePath) {
    try {
        const diff = gitOutput(cwd, ["diff", "--no-ext-diff", "--binary", "HEAD", "--", relativePath], MAX_HASH_BYTES);
        return { kind: "diff", digest: createHash("sha256").update(diff).digest("hex") };
    }
    catch {
        return { kind: "diff", digest: hashLargeDiff(cwd, relativePath) };
    }
}
function sameFingerprint(left, right) {
    if (!left || left.kind !== "diff" || right.kind !== "diff")
        return false;
    return left.digest === right.digest;
}
export function snapshotTrackedMutations(cwd) {
    try {
        const changed = changedTrackedFiles(gitOutput(cwd, CHANGED_FILES_ARGS));
        const fingerprints = {};
        for (const file of changed.paths)
            fingerprints[file] = fingerprintPath(cwd, file);
        return { source: "tracked-files", trackedOnly: true, cwd, dirtyFiles: changed.paths, fingerprints, truncated: changed.truncated };
    }
    catch (error) {
        return { source: "tracked-files", trackedOnly: true, cwd, dirtyFiles: [], fingerprints: {}, unavailable: gitFailureReason(error) };
    }
}
async function fingerprintPathAsync(cwd, relativePath) {
    try {
        const diff = await gitOutputAsync(cwd, ["diff", "--no-ext-diff", "--binary", "HEAD", "--", relativePath]);
        return { kind: "diff", digest: createHash("sha256").update(diff).digest("hex") };
    }
    catch {
        const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "pi-mutation-evidence-"));
        try {
            const diffPath = path.join(tempDir, "diff.bin");
            await gitOutputAsync(cwd, ["diff", "--no-ext-diff", "--binary", `--output=${diffPath}`, "HEAD", "--", relativePath]);
            return { kind: "diff", digest: await hashFileAsync(diffPath) };
        }
        finally {
            fs.rmSync(tempDir, { recursive: true, force: true });
        }
    }
}
/** A placed child on another machine edits that machine's disk, so local Git evidence stands in only as a marked placeholder. */
export function remoteMutationSnapshot(cwd) {
    return { source: "tracked-files", trackedOnly: true, cwd, dirtyFiles: [], fingerprints: {}, unavailable: "Local Git evidence is not authoritative for a pane-native remote run." };
}
export function remoteMutationEvidence(machine) {
    const changed = machine.initialGit && machine.finalGit ? machine.initialGit.head !== machine.finalGit.head || machine.initialGit.dirty !== machine.finalGit.dirty : undefined;
    return { source: "tracked-files", trackedOnly: true, changedFiles: [], attemptedMutation: changed === true, ...(changed === undefined ? { unavailable: "Remote Git before/after evidence was incomplete." } : {}) };
}
export async function collectTrackedMutationEvidence(snapshot, cwd = snapshot.cwd) {
    if (snapshot.unavailable) {
        return { source: "tracked-files", trackedOnly: true, changedFiles: [], attemptedMutation: false, unavailable: snapshot.unavailable };
    }
    try {
        const current = changedTrackedFiles(await gitOutputAsync(cwd, CHANGED_FILES_ARGS));
        const startDirty = new Set(snapshot.dirtyFiles);
        const candidates = new Set([...snapshot.dirtyFiles, ...current.paths]);
        const changedFiles = [];
        for (const file of candidates) {
            if (!startDirty.has(file)) {
                if (!snapshot.truncated)
                    changedFiles.push(file);
                continue;
            }
            if (!sameFingerprint(snapshot.fingerprints[file], await fingerprintPathAsync(cwd, file)))
                changedFiles.push(file);
        }
        changedFiles.sort();
        return {
            source: "tracked-files",
            trackedOnly: true,
            changedFiles,
            attemptedMutation: changedFiles.length > 0,
            truncated: snapshot.truncated || current.truncated || undefined,
        };
    }
    catch (error) {
        return { source: "tracked-files", trackedOnly: true, changedFiles: [], attemptedMutation: false, unavailable: gitFailureReason(error) };
    }
}
function formatPathList(paths) {
    if (paths.length === 0)
        return "none";
    const shown = paths.slice(0, MAX_TIMEOUT_FILES).join(", ");
    return paths.length > MAX_TIMEOUT_FILES ? `${shown}, ... (${paths.length - MAX_TIMEOUT_FILES} more)` : shown;
}
/** Keep status and completion details to bounded routing evidence, not raw output or effects. */
export function projectTimeoutRecovery(value) {
    if (!value || typeof value !== "object" || Array.isArray(value))
        return undefined;
    const source = value;
    const termination = source.termination === "timed-out" || source.termination === "stopped" ? source.termination : undefined;
    if (!termination || !Array.isArray(source.changedFiles))
        return undefined;
    const allChangedFiles = source.changedFiles.filter((file) => typeof file === "string");
    const changedFiles = allChangedFiles.slice(0, MAX_TIMEOUT_FILES);
    const reportStatus = source.reportStatus === "missing"
        || source.reportStatus === "written"
        || source.reportStatus === "not-requested"
        || source.reportStatus === "unknown"
        ? source.reportStatus
        : undefined;
    return {
        termination,
        changedFiles,
        ...(source.truncated === true || allChangedFiles.length > changedFiles.length ? { truncated: true } : {}),
        ...(source.recoveryNeeded === true ? { recoveryNeeded: true } : {}),
        ...(source.reason === "timed-out-with-dirty-worktree" ? { reason: source.reason } : {}),
        ...(reportStatus ? { reportStatus } : {}),
    };
}
/** Render only the bounded recovery route needed by a parent/operator. */
export function formatTimeoutRecoveryLines(value, indent = "") {
    const recovery = projectTimeoutRecovery(value);
    if (!recovery?.recoveryNeeded)
        return [];
    const changedFiles = recovery.changedFiles.length > 0
        ? `${recovery.changedFiles.join(", ")}${recovery.truncated ? ", …" : ""}`
        : "none";
    const changedFileCount = recovery.changedFiles.length > 0 ? `${recovery.changedFiles.length}${recovery.truncated ? "+" : ""}` : "0";
    return [
        `${indent}Recovery needed: review the diff and artifacts before resuming or launching dependent stages.`,
        `${indent}Recovery evidence: requested report: ${recovery.reportStatus ?? "unknown"}; changed tracked files: ${changedFiles} (${changedFileCount}); classification: ${recovery.reason ?? recovery.termination}`,
    ];
}
export function buildTimeoutRecoverySummary(input) {
    const warning = "Inspect partial changes before retrying or resuming the child.";
    const changedFiles = input.evidence.changedFiles.slice(0, MAX_TIMEOUT_FILES);
    let reportStatus = "not-requested";
    if (input.requiredOutputMissing === true)
        reportStatus = "missing";
    else if (input.requiredOutputMissing === false)
        reportStatus = "written";
    const recoveryNeeded = input.termination === "timed-out"
        && reportStatus === "missing"
        && input.evidence.changedFiles.length > 0;
    const lines = [
        "Recovery summary:",
        `- termination: ${input.termination}`,
        `- changed tracked files: ${input.evidence.unavailable ? `unavailable (${input.evidence.unavailable})` : formatPathList(input.evidence.changedFiles)}`,
    ];
    if (input.requiredOutputMissing !== undefined)
        lines.push(`- requested report: ${reportStatus}`);
    if (recoveryNeeded)
        lines.push("- Recovery needed: review the diff and artifacts before resuming or launching dependent stages.");
    if (input.currentTool)
        lines.push(`- active tool: ${input.currentTool}${input.currentToolArgs ? ` — ${input.currentToolArgs}` : ""}`);
    if (input.currentPath)
        lines.push(`- active path: ${input.currentPath}`);
    if (input.sessionFile)
        lines.push(`- session file: ${input.sessionFile}`);
    if (input.transcriptPath)
        lines.push(`- transcript: ${input.transcriptPath}`);
    if (input.artifactPaths?.outputPath)
        lines.push(`- output artifact: ${input.artifactPaths.outputPath}`);
    if (input.artifactPaths?.metadataPath)
        lines.push(`- metadata artifact: ${input.artifactPaths.metadataPath}`);
    lines.push(`Warning: ${warning}`);
    return {
        termination: input.termination,
        changedFiles,
        truncated: input.evidence.changedFiles.length > changedFiles.length || input.evidence.truncated || undefined,
        ...(recoveryNeeded ? { recoveryNeeded: true, reason: "timed-out-with-dirty-worktree" } : {}),
        reportStatus,
        currentTool: input.currentTool,
        currentToolArgs: input.currentToolArgs,
        currentPath: input.currentPath,
        sessionFile: input.sessionFile,
        transcriptPath: input.transcriptPath,
        artifactPaths: input.artifactPaths,
        warning,
        message: lines.join("\n"),
    };
}
