import * as fs from "node:fs";
import * as path from "node:path";
import { writeAtomicJson } from "../../shared/atomic-json.js";
import { resultFilePath, resultPayloadPathForSessionRun, writeAsyncResultFile } from "./result-files.js";
import { isTerminalAsyncState, updateActiveRunIndex } from "./active-run-index.js";
import { readProcessTerminal, unobservedRunnerExitPath } from "./process-terminal.js";
import { OWNING_SESSION_COMPLETION_OWNER } from "../../shared/completion-owner.js";
import { readStatus } from "../../shared/utils.js";
import { DIRS } from "../../shared/types.js";
import { resolveEffectiveThinking } from "../../shared/model-info.js";
import { normalizeParallelGroups } from "./parallel-groups.js";
import { nestedSummaryFromAsyncStatus, projectNestedEvents, resolveNestedAsyncDir, writeNestedEvent } from "../shared/nested-events.js";
import { assertWorkflowGraphHostSteps } from "../shared/host-step-status.js";
import { currentPidNamespaceScope } from "./pid-namespace.js";
import { currentBootId } from "./boot-id.js";
import { WORKFLOW_STOP_CAUSE_OWNER_EXITED } from "../../workflows/workflow-stop-cause.js";
function getErrorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
function readRunnerStartupDiagnostics(asyncDir) {
    const stderrPath = path.join(asyncDir, "runner.stderr.log");
    const maxBytes = 64 * 1024;
    let content;
    try {
        const stat = fs.statSync(stderrPath);
        if (stat.size <= 0)
            return undefined;
        const fd = fs.openSync(stderrPath, "r");
        try {
            const bytesToRead = Math.min(stat.size, maxBytes);
            const start = Math.max(0, stat.size - bytesToRead);
            const buffer = Buffer.alloc(bytesToRead);
            fs.readSync(fd, buffer, 0, bytesToRead, start);
            content = buffer.toString("utf-8").trim();
        }
        finally {
            fs.closeSync(fd);
        }
    }
    catch {
        return undefined;
    }
    if (!content)
        return undefined;
    const lines = content.split(/\r?\n/).slice(-30).join("\n");
    return lines.length > 4000 ? `${lines.slice(-4000)}\n[stderr tail truncated]` : lines;
}
function isNotFoundError(error) {
    return typeof error === "object"
        && error !== null
        && "code" in error
        && error.code === "ENOENT";
}
function appendJsonlBestEffort(filePath, payload) {
    try {
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
        fs.appendFileSync(filePath, `${JSON.stringify(payload)}\n`, "utf-8");
    }
    catch {
        // Repair status/result writes are the important path. A broken or full
        // diagnostic event log must not make stale-run reconciliation fail.
    }
}
function regularFileExists(filePath) {
    try {
        return fs.statSync(filePath).isFile();
    }
    catch (error) {
        if (isNotFoundError(error))
            return false;
        throw error;
    }
}
function readResultRepairData(resultPath) {
    try {
        const data = JSON.parse(fs.readFileSync(resultPath, "utf-8"));
        if (data.error !== undefined && typeof data.error !== "string")
            throw new Error(`Invalid async result file '${resultPath}': error must be a string.`);
        const state = data.success ? "complete" : data.state === "stopped" ? "stopped" : data.state === "rejected" ? "rejected" : data.state === "partial" ? "partial" : data.state === "paused" || data.exitCode === 0 ? "paused" : "failed";
        const results = Array.isArray(data.results)
            ? data.results.map((entry, index) => {
                if (!entry || typeof entry !== "object" || Array.isArray(entry))
                    return {};
                const child = entry;
                if (child.model !== undefined && typeof child.model !== "string")
                    throw new Error(`Invalid async result file '${resultPath}': results[${index}].model must be a string.`);
                if (child.thinking !== undefined && typeof child.thinking !== "string")
                    throw new Error(`Invalid async result file '${resultPath}': results[${index}].thinking must be a string.`);
                return child;
            })
            : undefined;
        return { state, ...(data.error ? { error: data.error } : {}), ...(results ? { results } : {}) };
    }
    catch (error) {
        if (isNotFoundError(error))
            return undefined;
        throw new Error(`Failed to read async result file '${resultPath}': ${getErrorMessage(error)}`, {
            cause: error instanceof Error ? error : undefined,
        });
    }
}
function childState(overallState, child) {
    if (child?.success === true)
        return "complete";
    if (child?.success === false)
        return "failed";
    return overallState;
}
function failureDiagnostic(value) {
    return typeof value === "string" && value.trim() ? value : undefined;
}
function terminalStatusFromResult(status, resultPath, now) {
    const repair = readResultRepairData(resultPath);
    if (!repair)
        return undefined;
    const rootError = failureDiagnostic(status.error)
        ?? failureDiagnostic(repair.error)
        ?? repair.results?.map((child) => child.success === false ? failureDiagnostic(child.error) : undefined).find(Boolean);
    const steps = (status.steps ?? []).map((step, index) => {
        if (step.status !== "running" && step.status !== "pending")
            return step;
        const child = repair.results?.[index];
        const state = childState(repair.state, child);
        const model = child?.model ?? step.model;
        const thinking = resolveEffectiveThinking(model, child?.thinking ?? step.thinking);
        return {
            ...step,
            status: state === "complete" ? "complete" : state,
            endedAt: step.endedAt ?? now,
            durationMs: step.startedAt !== undefined && step.durationMs === undefined ? Math.max(0, now - step.startedAt) : step.durationMs,
            exitCode: step.exitCode ?? (state === "complete" || state === "paused" ? 0 : 1),
            error: state === "failed" || state === "partial" || state === "stopped" ? step.error ?? child?.error : step.error,
            stopped: state === "stopped" ? true : step.stopped,
            sessionName: step.sessionName ?? child?.sessionName,
            sessionFile: step.sessionFile ?? child?.sessionFile,
            model,
            thinking,
            requestedModel: child?.requestedModel ?? step.requestedModel,
            contextOverflow: child?.contextOverflow ?? step.contextOverflow,
        };
    });
    const terminalStatus = {
        ...status,
        state: repair.state,
        ...(rootError && (repair.state === "failed" || repair.state === "partial") ? { error: rootError } : {}),
        ...(status.lifecycleArtifactVersion === 3 && (!status.processTerminal || status.processTerminal.state === "pending") ? {
            processTerminal: { version: 1, state: "unknown", runId: status.runId, runnerProcessInstanceId: "observer-unavailable", reason: "observer-unavailable" },
        } : {}),
        ...(repair.state === "stopped" ? { stopped: true } : {}),
        activityState: undefined,
        lastUpdate: now,
        endedAt: status.endedAt ?? now,
        steps,
    };
    delete terminalStatus.displayDismissedAt;
    return terminalStatus;
}
function buildStartedStatus(asyncDir, startedRun, now) {
    const startedAt = startedRun.startedAt ?? now;
    const agents = startedRun.agents?.length ? startedRun.agents : ["subagent"];
    const chainStepCount = startedRun.chainStepCount;
    const parallelGroups = chainStepCount !== undefined
        ? normalizeParallelGroups(startedRun.parallelGroups, agents.length, chainStepCount)
        : [];
    return {
        runId: startedRun.runId || path.basename(asyncDir),
        ...(startedRun.sessionId ? { sessionId: startedRun.sessionId } : {}),
        ...(startedRun.completionOwnerId ? { completionOwnerId: startedRun.completionOwnerId } : {}),
        mode: startedRun.mode ?? "single",
        state: "running",
        pid: startedRun.pid,
        pidNamespaceScope: currentPidNamespaceScope(),
        startedAt,
        lastUpdate: now,
        currentStep: 0,
        ...(chainStepCount !== undefined ? { chainStepCount } : {}),
        ...(parallelGroups.length ? { parallelGroups } : {}),
        steps: agents.map((agent) => ({
            agent,
            status: "running",
            startedAt,
        })),
        ...(startedRun.sessionFile ? { sessionFile: startedRun.sessionFile } : {}),
    };
}
/**
 * A dead workflow owner does not say how its detached children ended. A detached child this
 * workflow owns that already wrote its own terminal status keeps that outcome instead of
 * inheriting the owner failure.
 */
function settledWorkflowChildStatus(asyncDir, workflowRunId, step, now) {
    const childRunId = step.runId;
    if (step.async !== true || step.parentWorkflowRunId !== workflowRunId || !childRunId || childRunId === workflowRunId
        || childRunId !== path.basename(childRunId) || childRunId === "." || childRunId === "..")
        return undefined;
    const child = readStatus(path.join(path.dirname(asyncDir), childRunId));
    if (!child || child.runId !== childRunId || child.parentWorkflowRunId !== workflowRunId || !isTerminalAsyncState(child.state))
        return undefined;
    if (step.workflowKey !== undefined && child.workflowKey !== step.workflowKey)
        return undefined;
    const state = child.state;
    const childStep = child.steps?.[0];
    const endedAt = child.endedAt ?? step.endedAt ?? now;
    const settled = {
        ...step,
        status: state,
        activityState: undefined,
        endedAt,
        durationMs: step.startedAt !== undefined ? Math.max(0, endedAt - step.startedAt) : step.durationMs,
        exitCode: childStep?.exitCode ?? (state === "complete" ? 0 : 1),
        error: state === "complete" ? undefined : childStep?.error ?? child.error ?? step.error,
        stopped: state === "stopped" ? true : step.stopped,
    };
    if (settled.error === undefined)
        delete settled.error;
    if (settled.stopped === undefined)
        delete settled.stopped;
    return settled;
}
function buildFailedRepair(status, asyncDir, now, reason, ownerExited = false, adoptCompletionOwnerId) {
    const runId = status.runId || path.basename(asyncDir);
    const pid = typeof status.pid === "number" ? status.pid : "unknown";
    // A dead workflow host is the Pi process itself; its journal keeps the finished children for a relaunch.
    const exitedWorkflow = ownerExited && status.mode === "workflow" ? status.workflow : undefined;
    // Its owner process is dead, so nothing else can deliver its notice: an owning session that repairs it
    // adopts it, and a repair elsewhere leaves it to whichever session owns the run.
    const completionOwnerId = exitedWorkflow ? adoptCompletionOwnerId || OWNING_SESSION_COMPLETION_OWNER : status.completionOwnerId;
    const terminal = readProcessTerminal(asyncDir, { runId }) ?? status.processTerminal;
    const runnerExit = terminal?.state === "observed" || terminal?.state === "unknown"
        ? terminal.instances?.find((instance) => instance.kind === "runner" && instance.processInstanceId === terminal.runnerProcessInstanceId)
        : undefined;
    const exitText = runnerExit?.kind === "runner"
        ? `exited with code ${runnerExit.exitCode ?? "none"}${runnerExit.signal ? ` (signal ${runnerExit.signal})` : ""}`
        : "exited or disappeared";
    const baseMessage = reason ?? (exitedWorkflow
        ? `The Pi process (PID ${pid}) that ran workflow ${runId} exited before the workflow finished. Marked run failed by stale-run reconciliation. Its finished children are kept.`
        : `Async runner process ${pid} ${exitText} before writing a result. Marked run failed by stale-run reconciliation.`);
    const diagnostics = readRunnerStartupDiagnostics(asyncDir);
    const message = diagnostics ? `${baseMessage}\n\nRunner stderr tail:\n${diagnostics}` : baseMessage;
    const steps = status.steps?.length ? status.steps : [{ agent: "subagent", status: "running" }];
    const repairedSteps = steps.map((step) => {
        if (step.status !== "running" && step.status !== "pending")
            return step;
        let settled;
        let childReadError;
        try {
            settled = settledWorkflowChildStatus(asyncDir, runId, step, now);
        }
        catch (error) {
            // An unreadable child status must not block repairing the dead owner.
            childReadError = error instanceof Error ? error.message : String(error);
        }
        if (settled)
            return settled;
        return {
            ...step,
            status: "failed",
            activityState: undefined,
            endedAt: step.endedAt ?? now,
            durationMs: step.startedAt !== undefined && step.durationMs === undefined ? Math.max(0, now - step.startedAt) : step.durationMs,
            exitCode: step.exitCode ?? 1,
            error: step.error ?? (childReadError ? `${message} (child status unreadable: ${childReadError})` : message),
        };
    });
    const repairedStatus = {
        ...status,
        state: "failed",
        ...(status.lifecycleArtifactVersion === 3 && (!status.processTerminal || status.processTerminal.state === "pending") ? {
            processTerminal: { version: 1, state: "unknown", runId, runnerProcessInstanceId: "observer-unavailable", reason: "stale-repair" },
        } : {}),
        activityState: undefined,
        lastUpdate: now,
        endedAt: now,
        steps: repairedSteps,
        // Read from the pre-repair status: the repair time would make an old crash look new.
        ...(exitedWorkflow ? { workflow: { ...exitedWorkflow, stopCause: WORKFLOW_STOP_CAUSE_OWNER_EXITED, ownerExitedAt: status.lastUpdate ?? status.startedAt } } : {}),
        ...(completionOwnerId ? { completionOwnerId } : {}),
    };
    const resultAgent = repairedSteps[status.currentStep ?? 0]?.agent ?? repairedSteps[0]?.agent ?? "subagent";
    return {
        status: repairedStatus,
        message,
        result: {
            id: runId,
            agent: resultAgent,
            mode: status.mode,
            ...(exitedWorkflow ? { workflow: { stopCause: WORKFLOW_STOP_CAUSE_OWNER_EXITED } } : {}),
            ...(completionOwnerId ? { completionOwnerId } : {}),
            ...(status.completionOwnerProcess ? { completionOwnerProcess: status.completionOwnerProcess } : {}),
            ...(status.parentWorkflowRunId ? { parentWorkflowRunId: status.parentWorkflowRunId } : {}),
            ...(status.workflowKey ? { workflowKey: status.workflowKey } : {}),
            success: false,
            state: "failed",
            summary: message,
            results: repairedSteps.map((step) => ({
                agent: step.agent,
                ...(step.sessionName ? { sessionName: step.sessionName } : {}),
                output: step.status === "complete" || step.status === "completed" ? "" : message,
                error: step.status === "complete" || step.status === "completed" ? undefined : step.error ?? message,
                success: step.status === "complete" || step.status === "completed",
                model: step.model,
                requestedModel: step.requestedModel,
                contextOverflow: step.contextOverflow,
                sessionFile: step.sessionFile,
            })),
            exitCode: 1,
            timestamp: now,
            durationMs: Math.max(0, now - status.startedAt),
            asyncDir,
            sessionId: status.sessionId,
            sessionFile: status.sessionFile,
        },
    };
}
function writeFailedRepair(asyncDir, status, resultPath, now, reason, ownerExited = false, adoptCompletionOwnerId) {
    const repair = buildFailedRepair(status, asyncDir, now, reason, ownerExited, adoptCompletionOwnerId);
    if (repair.result.sessionId)
        writeAsyncResultFile(resultPath, repair.result);
    writeAtomicJson(path.join(asyncDir, "status.json"), repair.status);
    updateActiveRunIndex(asyncDir, repair.status.state, repair.status.toolCallId);
    appendJsonlBestEffort(path.join(asyncDir, "events.jsonl"), {
        type: "subagent.run.repaired_stale",
        ts: now,
        runId: repair.status.runId,
        pid: status.pid,
        ...(repair.result.sessionId ? { resultPath } : {}),
        message: repair.message,
    });
    return { status: repair.status, repaired: true, ...(repair.result.sessionId ? { resultPath } : {}), message: repair.message };
}
function terminal(state) {
    return state === "complete" || state === "failed" || state === "partial" || state === "paused" || state === "stopped" || state === "rejected";
}
function* nestedRuns(children) {
    for (const child of children ?? []) {
        yield child;
        yield* nestedRuns(child.children);
        yield* nestedRuns(child.steps?.flatMap((step) => step.children ?? []));
    }
}
export function reconcileNestedAsyncDescendants(route, options = {}) {
    const registry = projectNestedEvents(route);
    for (const run of nestedRuns(registry.children)) {
        if (run.state !== "running" && run.state !== "queued")
            continue;
        const asyncDir = resolveNestedAsyncDir(route.rootRunId, run);
        if (!asyncDir)
            continue;
        const result = reconcileAsyncRun(asyncDir, {
            ...options,
            resultsDir: path.join(options.resultsDir ?? DIRS.results, "nested", route.rootRunId),
        });
        const status = result.status;
        if (!status)
            continue;
        if (!result.repaired && !terminal(status.state))
            continue;
        const ts = options.now?.() ?? Date.now();
        writeNestedEvent(route, {
            type: terminal(status.state) ? "subagent.nested.completed" : "subagent.nested.updated",
            ts,
            parentRunId: run.parentRunId,
            parentStepIndex: run.parentStepIndex,
            child: nestedSummaryFromAsyncStatus(status, asyncDir, {
                id: run.id,
                parentRunId: run.parentRunId,
                parentStepIndex: run.parentStepIndex,
                depth: run.depth,
                path: run.path,
                mode: run.mode,
                ts,
            }),
        });
    }
}
export function checkPidLiveness(pid, kill = process.kill, probeZombie = false) {
    try {
        kill(pid, 0);
        if (probeZombie && process.platform === "linux") {
            try {
                const stat = fs.readFileSync(`/proc/${pid}/stat`, "utf-8");
                const closeParen = stat.lastIndexOf(") ");
                if (closeParen >= 0 && stat[closeParen + 2] === "Z")
                    return "dead";
            }
            catch {
                // Fall back to kill(pid, 0) when procfs is unavailable or unreadable.
            }
        }
        return "alive";
    }
    catch (error) {
        const code = typeof error === "object" && error !== null && "code" in error
            ? error.code
            : undefined;
        if (code === "ESRCH")
            return "dead";
        if (code === "EPERM")
            return "unknown";
        return "unknown";
    }
}
export function isRecordedPid(value) {
    if (!value || typeof value !== "object")
        return false;
    const { pid, pidNamespaceScope, bootId } = value;
    return typeof pid === "number" && Number.isSafeInteger(pid) && pid > 0
        && (pidNamespaceScope === undefined || typeof pidNamespaceScope === "string")
        && (bootId === undefined || typeof bootId === "string");
}
/**
 * Liveness of a pid saved in a status file. A pid saved under another boot is dead without a
 * probe, but only when both sides are in the same pid namespace or neither records one: a
 * macOS host reading a Linux container's runs must not compare their boot ids.
 */
export function checkRecordedPidLiveness(recorded, observation = { observedScope: currentPidNamespaceScope(), observedBootId: currentBootId() }) {
    const { observedScope, observedBootId } = observation;
    if (recorded.pidNamespaceScope === observedScope && recorded.bootId && observedBootId && recorded.bootId !== observedBootId)
        return "dead";
    // An observer without a scope (macOS/Windows host sharing a container's temp root) cannot match a recorded one.
    const scopeMismatch = recorded.pidNamespaceScope !== undefined && recorded.pidNamespaceScope !== observedScope;
    // A local zombie is evidence about this pid only when its namespace is known to match.
    const scopeVerified = recorded.pidNamespaceScope !== undefined && recorded.pidNamespaceScope === observedScope;
    const liveness = observation.probe
        ? observation.probe(recorded.pid)
        : checkPidLiveness(recorded.pid, observation.kill, scopeVerified);
    return liveness === "dead" && scopeMismatch ? "unknown" : liveness;
}
/**
 * Only the Pi process that spawned a runner sees it close and writes its process-terminal proof. When that
 * process is gone, a finished run whose runner is confirmed dead would report a `pending` proof forever.
 * Record it as unknown, never observed: nobody saw the exit. A workflow's pid is its host Pi, not a runner.
 * The verdict goes to its own file, never process-terminal.json, so a close the launching Pi observes after the
 * pending read above still wins.
 */
export function settleUnobservedRunnerExit(asyncDir, status, observation = { observedScope: currentPidNamespaceScope(), observedBootId: currentBootId() }) {
    const runnerProcessInstanceId = status.processTerminal?.runnerProcessInstanceId;
    if (!terminal(status.state) || status.mode === "workflow" || status.processTerminal?.state !== "pending" || !runnerProcessInstanceId)
        return;
    if (typeof status.pid !== "number" || status.pidNamespaceScope !== observation.observedScope)
        return;
    if (readProcessTerminal(asyncDir, { runId: status.runId, runnerProcessInstanceId })?.state !== "pending")
        return;
    if (checkRecordedPidLiveness({ pid: status.pid, pidNamespaceScope: status.pidNamespaceScope, bootId: status.bootId }, observation) !== "dead")
        return;
    try {
        const proof = {
            version: 1,
            state: "unknown",
            runId: status.runId,
            runnerProcessInstanceId,
            reason: "observer-unavailable",
            diagnostic: `Runner PID ${status.pid} is gone and no Pi recorded its exit.`,
        };
        writeAtomicJson(unobservedRunnerExitPath(asyncDir), proof);
    }
    catch {
        // The proof stays pending; the next status read tries again.
    }
}
export function reconcileAsyncRun(asyncDir, options = {}, observeStatus) {
    const now = options.now?.() ?? Date.now();
    const status = readStatus(asyncDir);
    observeStatus?.(status);
    const startedStatus = !status && options.startedRun ? buildStartedStatus(asyncDir, options.startedRun, now) : undefined;
    const effectiveStatus = status ?? startedStatus;
    if (!effectiveStatus)
        return { status: null, repaired: false };
    assertWorkflowGraphHostSteps(effectiveStatus.workflowGraph, path.join(asyncDir, "status.json"), effectiveStatus.runId);
    const statusPath = path.join(asyncDir, "status.json");
    for (const [index, step] of (effectiveStatus.steps ?? []).entries()) {
        const stepRecord = step;
        if (stepRecord.model !== undefined && typeof stepRecord.model !== "string")
            throw new Error(`Invalid async status file '${statusPath}': steps[${index}].model must be a string.`);
        if (stepRecord.thinking !== undefined && typeof stepRecord.thinking !== "string")
            throw new Error(`Invalid async status file '${statusPath}': steps[${index}].thinking must be a string.`);
    }
    const runId = effectiveStatus.runId || path.basename(asyncDir);
    const resultsDir = options.resultsDir ?? DIRS.results;
    const resultPath = resultFilePath(resultsDir, runId);
    const existingResultPath = effectiveStatus.sessionId
        ? resultPayloadPathForSessionRun(resultsDir, effectiveStatus.sessionId, runId) ?? (regularFileExists(resultPath) ? resultPath : undefined)
        : regularFileExists(resultPath) ? resultPath : undefined;
    const staleAfterMs = options.staleAlivePidMs ?? 24 * 60 * 60 * 1000;
    const lastUpdate = effectiveStatus.lastUpdate ?? effectiveStatus.startedAt;
    const observedScope = options.pidNamespaceScope ? options.pidNamespaceScope() : currentPidNamespaceScope();
    const observation = { kill: options.kill, observedScope, observedBootId: options.bootId ? options.bootId() : currentBootId() };
    const runnerLiveness = (pid) => checkRecordedPidLiveness({ pid, pidNamespaceScope: effectiveStatus.pidNamespaceScope, bootId: effectiveStatus.bootId }, observation);
    if (status)
        settleUnobservedRunnerExit(asyncDir, status, observation);
    if (existingResultPath) {
        // A live runner writes its result before its final status; repairing in that window would replace
        // its pending exit proof with a placeholder. Only a confirmed-alive pid defers: a result is better
        // evidence than an unprobeable pid, and a pid from another pid namespace can be alive here as an unrelated
        // process. A workflow's pid is its host Pi process, which outlives the workflow.
        const runnerStillFinishing = effectiveStatus.state === "running" && effectiveStatus.mode !== "workflow" && typeof effectiveStatus.pid === "number"
            && effectiveStatus.pidNamespaceScope === observedScope
            && now - lastUpdate <= staleAfterMs && runnerLiveness(effectiveStatus.pid) === "alive";
        const terminalStatus = (effectiveStatus.state === "running" || effectiveStatus.state === "queued") && !runnerStillFinishing
            ? terminalStatusFromResult(effectiveStatus, existingResultPath, now)
            : undefined;
        if (terminalStatus) {
            const currentStatus = readStatus(asyncDir);
            const currentRootError = failureDiagnostic(currentStatus?.error);
            const currentTerminal = currentStatus?.processTerminal?.state === "observed" || currentStatus?.processTerminal?.state === "unknown"
                ? currentStatus.processTerminal
                : undefined;
            const steps = terminalStatus.steps?.map((step, index) => {
                const currentStepTerminal = currentStatus?.steps?.[index]?.processTerminal;
                return currentStepTerminal?.state === "observed" || currentStepTerminal?.state === "unknown"
                    ? { ...step, processTerminal: currentStepTerminal }
                    : step;
            });
            const statusToWrite = {
                ...terminalStatus,
                ...(currentRootError ? { error: currentRootError } : {}),
                ...(currentTerminal ? { processTerminal: currentTerminal } : {}),
                ...(steps ? { steps } : {}),
            };
            writeAtomicJson(statusPath, statusToWrite);
            updateActiveRunIndex(asyncDir, statusToWrite.state, statusToWrite.toolCallId);
            return { status: statusToWrite, repaired: true, resultPath: existingResultPath, message: "Existing async result file was used to repair stale running status." };
        }
        if (effectiveStatus.displayDismissedAt === undefined)
            return { status: effectiveStatus, repaired: false, resultPath: existingResultPath };
    }
    if (effectiveStatus.displayDismissedAt !== undefined) {
        return { status: null, repaired: false, resultPath };
    }
    if (effectiveStatus.state !== "running" || typeof effectiveStatus.pid !== "number") {
        return { status: status ?? null, repaired: false, resultPath };
    }
    if (!status) {
        const startedAt = options.startedRun?.startedAt ?? effectiveStatus.startedAt;
        if (now - startedAt < (options.missingStatusGraceMs ?? 1000)) {
            return { status: null, repaired: false, resultPath };
        }
    }
    const liveness = runnerLiveness(effectiveStatus.pid);
    if (liveness !== "dead") {
        if (now - lastUpdate <= staleAfterMs)
            return { status: status ?? null, repaired: false, resultPath };
        const probe = liveness === "alive" ? "is still live" : "cannot be probed from this process";
        const message = `Async runner PID ${effectiveStatus.pid} ${probe}; status has not updated for ${now - lastUpdate}ms, so stale-run reconciliation marked the run failed because PID ownership is unverified.`;
        return writeFailedRepair(asyncDir, effectiveStatus, resultPath, now, message);
    }
    return writeFailedRepair(asyncDir, effectiveStatus, resultPath, now, undefined, true, options.adoptCompletionOwnerId);
}
