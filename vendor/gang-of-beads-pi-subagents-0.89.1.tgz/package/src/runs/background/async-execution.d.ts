import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import type { ParentProviderRegistry } from "../shared/child-session.ts";
import { type AgentConfig, type UnknownAgentDiagnosticContext } from "../../agents/agents.ts";
import { type ClaudeCodeOverride } from "../shared/claude-code-adapter.ts";
import { type ChainStep } from "../../shared/settings.ts";
import { type RunnerStep } from "../shared/parallel-utils.ts";
import type { ContextMode } from "../shared/context-mode.ts";
import { type AvailableModelInfo, type KnownProviders, type ModelOrigin, type ParentModel } from "../shared/model-resolution.ts";
import { type ModelScopeConfig } from "../shared/model-scope.ts";
import { type ThinkingLevel } from "../../shared/thinking-ceiling.ts";
import { buildWorkflowGraphSnapshot } from "../shared/workflow-graph.ts";
import { type AcceptanceInput, type AgentContract, type ArtifactConfig, type Details, type IntercomBridgeConfig, type JsonSchemaObject, type MaxOutputConfig, type NestedRouteInfo, type ResolvedControlConfig, type ResolvedToolBudget, type RunFanoutBudgetDescriptor, type ToolBudgetConfig, type SubagentRunMode, type WorkflowLaneMetadata, type UsageBudgetConfig } from "../../shared/types.ts";
import { type ChildRuntimeConfig } from "../shared/child-runtime-config.ts";
import type { ImportedAsyncRoot } from "./chain-root-attachment.ts";
import type { SessionLeaseRequest } from "../shared/session-lease.ts";
import type { ActiveAsyncCapacityHandle } from "./active-async-capacity.ts";
import { type RequiredRunnerLauncher } from "../../shared/types.ts";
import { type ResolvedSubagentCapabilityCeiling } from "../shared/capability-ceiling.ts";
import { type PermissionConfig } from "../shared/permissions.ts";
import { type ExtensionBindings } from "../shared/extension-bindings.ts";
import { type RequiredChildExtensionSnapshot } from "../../shared/required-child-extensions.ts";
interface AsyncExecutionContext {
    pi: ExtensionAPI;
    cwd: string;
    currentSessionId: string;
    completionOwnerId?: string;
    /** Parent Pi session id (`getSessionId()`): keys permission-system ask forwarding and capability ceilings. */
    parentSessionId?: string;
    /** Parent session file, recorded as each new child session's `parentSession` header. */
    parentSessionFile?: string;
    permissions?: PermissionConfig;
    currentModelProvider?: string;
    currentModel?: ParentModel;
    scopedModelIds?: string[];
    knownProviders?: KnownProviders;
    /** Optional model-scope enforcement resolved from subagent settings. */
    modelScope?: ModelScopeConfig;
    modelResponseAliases?: Record<string, string[]>;
    /** Whether the parent session has an interactive UI. */
    interactive?: boolean;
    /** User-configured runner launchers; an agent's `launcher` must name one of them. */
    runnerLaunchers?: Record<string, string[]>;
    /** The executor's own child runtime when the launch comes from an in-process child. */
    childRuntime?: ChildRuntimeConfig;
    /** The launching session's project trust; undefined when the host has no trust concept. */
    projectTrusted?: boolean;
    /** The parent's model registry, read at launch to name a provider an extension registered there. */
    parentProviderRegistry?: Pick<ParentProviderRegistry, "getRegisteredProviderIds">;
}
export declare const DEFAULT_ASYNC_TIMEOUT_MS: number;
interface AsyncChainParams {
    chain: ChainStep[];
    task?: string;
    /** Raw caller-facing goal used only by the started event. */
    goal?: string;
    attachRoot?: ImportedAsyncRoot & {
        agent: string;
        outputName?: string;
        label?: string;
    };
    resultMode?: SubagentRunMode;
    agents: AgentConfig[];
    /** Original discovery provenance, retained by normal callers for unknown-agent diagnostics. */
    unknownAgentDiagnosticContext?: UnknownAgentDiagnosticContext;
    ctx: AsyncExecutionContext;
    availableModels?: AvailableModelInfo[];
    cwd?: string;
    maxOutput?: MaxOutputConfig;
    machine?: string;
    /** Launch cwd as typed when a machine is set: a path on that machine, never resolved locally. */
    machineCwd?: string;
    artifactsDir?: string;
    artifactConfig: ArtifactConfig;
    shareEnabled: boolean;
    sessionRoot?: string;
    agentContract?: AgentContract;
    chainSkills?: string[];
    sessionFilesByFlatIndex?: (string | undefined)[];
    thinkingOverridesByFlatIndex?: (AgentConfig["thinking"] | undefined)[];
    contextForAgent?: (agentName: string) => ContextMode;
    progressDir?: string;
    dynamicFanoutMaxItems?: number;
    maxSubagentDepth: number;
    waitToolEnabled?: boolean;
    waitToolDefaultTimeoutMs?: number;
    worktreeSetupHook?: string;
    worktreeSetupHookTimeoutMs?: number;
    worktreeBaseDir?: string;
    baseRef?: string;
    worktreeProvider?: import("../../shared/types.ts").WorktreeProvider;
    worktreeBranchPrefix?: string;
    controlConfig?: ResolvedControlConfig;
    controlIntercomTarget?: string;
    childIntercomTarget?: (agent: string, index: number) => string | undefined;
    nestedRoute?: NestedRouteInfo;
    acceptance?: AcceptanceInput;
    fast?: boolean;
    timeoutMs?: number;
    toolBudget?: ResolvedToolBudget;
    usageBudget?: UsageBudgetConfig;
    configToolBudget?: ResolvedToolBudget;
    /** Optional per-call hard toolTimeoutMs override (highest precedence). */
    callToolTimeoutMs?: number;
    /** Global config.toolTimeoutMs (third precedence, after agent frontmatter). */
    configToolTimeoutMs?: number;
    /** PI_SUBAGENT_TOOL_TIMEOUT_MS override (lowest precedence). */
    toolTimeoutMsEnv?: string | undefined;
    /** Global cap on simultaneously-running subagent tasks within the async run. */
    globalConcurrencyLimit?: number;
    capabilityCeiling?: ResolvedSubagentCapabilityCeiling;
    requiredExtensions?: RequiredChildExtensionSnapshot;
    thinkingCeiling?: ThinkingLevel;
    runFanoutBudget?: RunFanoutBudgetDescriptor;
    parentWorkflowRunId?: string;
    workflowKey?: string;
    lane?: WorkflowLaneMetadata;
    activeAsyncCapacity?: ActiveAsyncCapacityHandle;
}
interface AsyncSingleParams {
    /** Originating executor invocation, distinct from the async run id. */
    toolCallId?: string;
    agent: string;
    task?: string;
    /** Raw caller-facing goal used only by the started event. */
    goal?: string;
    agentConfig: AgentConfig;
    /** Agent contract before per-run bridge injection, used only for recovery persistence. */
    recoveryAgentConfig?: AgentConfig;
    requiredExtensions?: RequiredChildExtensionSnapshot;
    ctx: AsyncExecutionContext;
    cwd?: string;
    requestedCwd?: string;
    machine?: string;
    /** Launch cwd as typed when a machine is set: a path on that machine, never resolved locally. */
    machineCwd?: string;
    /** The launcher and agent definition digest the call requires; checked here, on what this launch spawns. */
    requireLauncher?: RequiredRunnerLauncher;
    /** A revived run's inherited requirement: recorded for its own resumes, not checked here (resume already checked it). */
    carriedRequiredLauncher?: RequiredRunnerLauncher;
    maxOutput?: MaxOutputConfig;
    artifactsDir?: string;
    artifactConfig: ArtifactConfig;
    shareEnabled: boolean;
    sessionRoot?: string;
    sessionDir?: string;
    sessionFile?: string;
    revivalLease?: SessionLeaseRequest;
    context?: ContextMode;
    skills?: string[];
    output?: string | boolean;
    reads?: string[] | false;
    outputMode?: "inline" | "file-only";
    outputBaseDir?: string;
    outputClaimPath?: string;
    agentContract?: AgentContract;
    structuredOutputSchema?: JsonSchemaObject;
    modelOverride?: string;
    modelOverrideFromParent?: boolean;
    modelOrigin?: ModelOrigin;
    fast?: boolean;
    thinkingOverride?: AgentConfig["thinking"];
    availableModels?: AvailableModelInfo[];
    maxSubagentDepth: number;
    waitToolEnabled?: boolean;
    waitToolDefaultTimeoutMs?: number;
    worktreeSetupHook?: string;
    worktreeSetupHookTimeoutMs?: number;
    worktreeBaseDir?: string;
    baseRef?: string;
    worktreeProvider?: import("../../shared/types.ts").WorktreeProvider;
    worktreeBranchPrefix?: string;
    worktree?: boolean;
    controlConfig?: ResolvedControlConfig;
    intercomBridge?: IntercomBridgeConfig;
    controlIntercomTarget?: string;
    childIntercomTarget?: (agent: string, index: number) => string | undefined;
    nestedRoute?: NestedRouteInfo;
    acceptance?: AcceptanceInput;
    timeoutMs?: number;
    absoluteDeadlineAt?: number;
    /** Optional per-call hard toolTimeoutMs override (highest precedence). */
    toolTimeoutMs?: number;
    /** Steer the child to checkpoint and stop this many ms before the run deadline (resolved call param ?? config). */
    checkpointBeforeDeadlineMs?: number;
    toolBudget?: ResolvedToolBudget | ToolBudgetConfig;
    usageBudget?: UsageBudgetConfig;
    configToolBudget?: ResolvedToolBudget;
    /** Global config.toolTimeoutMs (third precedence, after agent frontmatter). */
    configToolTimeoutMs?: number;
    /** PI_SUBAGENT_TOOL_TIMEOUT_MS override (lowest precedence). */
    toolTimeoutMsEnv?: string | undefined;
    allowZeroToolBudget?: boolean;
    capabilityCeiling?: ResolvedSubagentCapabilityCeiling;
    thinkingCeiling?: ThinkingLevel;
    runFanoutBudget?: RunFanoutBudgetDescriptor;
    parentWorkflowRunId?: string;
    workflowKey?: string;
    lane?: WorkflowLaneMetadata;
    workflowAwaitAsync?: boolean;
    activeAsyncCapacity?: ActiveAsyncCapacityHandle;
    externalJobFollowUp?: {
        sourceRunId: string;
        sourceStepIndex: number;
        parentProviderJobId: string;
        requestId: string;
        requestDigest: string;
    };
    extensionBindings?: ExtensionBindings;
}
interface AsyncExecutionResult {
    content: Array<{
        type: "text";
        text: string;
    }>;
    details: Details;
    isError?: boolean;
}
export interface AsyncRunnerStepBuildParams {
    chain: ChainStep[];
    task?: string;
    attachRoot?: ImportedAsyncRoot & {
        agent: string;
        outputName?: string;
        label?: string;
    };
    resultMode?: SubagentRunMode;
    agents: AgentConfig[];
    /** Exact discovery provenance for failed resolution; omission triggers defensive fallback discovery. */
    unknownAgentDiagnosticContext?: UnknownAgentDiagnosticContext;
    ctx: AsyncExecutionContext;
    availableModels?: AvailableModelInfo[];
    cwd?: string;
    machine?: string;
    machineCwd?: string;
    chainSkills?: string[];
    sessionFilesByFlatIndex?: (string | undefined)[];
    thinkingOverridesByFlatIndex?: (AgentConfig["thinking"] | undefined)[];
    contextForAgent?: (agentName: string) => ContextMode;
    progressDir?: string;
    agentContract?: AgentContract;
    dynamicFanoutMaxItems?: number;
    maxSubagentDepth: number;
    waitToolEnabled?: boolean;
    waitToolDefaultTimeoutMs?: number;
    worktreeBaseDir?: string;
    worktreeProvider?: import("../../shared/types.ts").WorktreeProvider;
    worktreeBranchPrefix?: string;
    asyncDir: string;
    outputBaseDir?: string;
    validateOutputBindings?: boolean;
    fast?: boolean;
    toolBudget?: ResolvedToolBudget;
    configToolBudget?: ResolvedToolBudget;
    /** Optional per-call hard toolTimeoutMs override from the subagent invocation. */
    callToolTimeoutMs?: number;
    /** Global config.toolTimeoutMs (third precedence, after agent frontmatter). */
    configToolTimeoutMs?: number;
    /** PI_SUBAGENT_TOOL_TIMEOUT_MS override (lowest precedence). */
    toolTimeoutMsEnv?: string | undefined;
    capabilityCeiling?: ResolvedSubagentCapabilityCeiling;
    /** Retained snapshot from the launch being continued; takes precedence over the live registry, as in single launches. */
    requiredExtensions?: RequiredChildExtensionSnapshot;
    thinkingCeiling?: ThinkingLevel;
}
export type AsyncRunnerStepBuildResult = {
    steps: RunnerStep[];
    runnerCwd: string;
    workflowGraph: ReturnType<typeof buildWorkflowGraphSnapshot>;
    eventChain: ChainStep[];
    originalTask?: string;
    /** Launcher name shared by every new step; absent when they run unwrapped. */
    launcher?: string;
} | {
    error: string;
};
export declare function formatAsyncStartedMessage(headline: string, interactive: boolean): string;
/** Check whether detached async execution has a supported runtime. */
export declare function isAsyncAvailable(): boolean;
export declare function resolveAsyncRunnerLogPaths(cfg: object): {
    stdoutPath: string;
    stderrPath: string;
} | undefined;
export declare function emitProcessTerminalEvent(ctx: AsyncExecutionContext, proof: unknown): void;
/**
 * An explicit `thinking: false` clears the level, so only `undefined` falls
 * through to the agent's own value. Treating `false` as absent would silently
 * apply the agent default the caller just cleared.
 */
export declare function resolveClaudeCodeThinking(source: string | false | undefined, fallback: string | false | undefined): string | undefined;
/** A pinned Claude Code model cannot survive pane-native saved-machine placement, which
 * owns the remote model registry, so the combination fails instead of losing both flags. */
export declare function assertClaudeCodeOverrideIsLocal(agent: string, machine: string | undefined, override: ClaudeCodeOverride | undefined): void;
export declare function buildAsyncRunnerSteps(id: string, params: AsyncRunnerStepBuildParams): AsyncRunnerStepBuildResult;
export declare function executeAsyncChain(id: string, params: AsyncChainParams): AsyncExecutionResult | Promise<AsyncExecutionResult>;
export declare function workflowAwaitedAsyncResultPath(asyncDir: string): string;
export declare function executeAsyncSingle(id: string, params: AsyncSingleParams): AsyncExecutionResult | Promise<AsyncExecutionResult>;
export {};
