import {
  RUNTIME_AGENT_REGISTER_EVENT,
  RUNTIME_AGENT_REGISTER_VERSION,
  registerAgentViaEvents
} from "./chunk-5TXWZB73.js";
import {
  registerRuntimeAgent
} from "./chunk-SWGB2P5J.js";
import "./chunk-LWH7IGI3.js";
import "./chunk-JEZOSEWG.js";
import "./chunk-YFCK7H2S.js";
import "./chunk-QXASAHIA.js";
export {
  RUNTIME_AGENT_REGISTER_EVENT,
  RUNTIME_AGENT_REGISTER_VERSION,
  registerRuntimeAgent as registerAgent,
  registerAgentViaEvents
};
