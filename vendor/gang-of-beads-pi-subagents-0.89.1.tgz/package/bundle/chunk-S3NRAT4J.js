import {
  DEFAULT_WATCHDOG_CONFIG,
  MainWatchdogRuntime,
  WATCHDOG_DIFF_TOOL_NAME,
  captureWatchdogDiffBaseline,
  childSupervisorMetadata,
  createMainWatchdogReview,
  createWatchdogDiffTool,
  createWatchdogWarningMessage,
  drainOutstandingWork,
  evaluateChildToolDiagnostic,
  formatWatchdogCwdSection,
  registerWaitTool,
  resolveCurrentSessionId,
  resolveWatchdogReviewModel,
  startWatchdogDiffBaselineCapture
} from "./chunk-MMWJRM2H.js";
import {
  agentStreamOptions,
  opencodeSessionHeaders
} from "./chunk-U753SUBC.js";
import {
  registerNativeSupervisorClient
} from "./chunk-VEEUXJDO.js";
import {
  MODEL_ONLY_TOOL
} from "./chunk-HXRB42AF.js";
import {
  inheritedNestedRouteOf
} from "./chunk-DHY5TY2Y.js";
import {
  CHILD_WATCHDOG_STATUS_EVENT,
  DEFAULT_WAIT_TOOL_NAME,
  MISSING_STRUCTURED_ACCEPTANCE_REPORT_ERROR,
  SUBAGENT_WATCHDOG_WARNING_TYPE,
  appendPermissionAudit,
  createStructuredOutputToolParameters,
  decodeChildWatchdogConfig,
  getAgentDir,
  permissionArgsPreview,
  permissionDecision,
  prepareStructuredOutputArguments,
  setWaitToolName,
  shouldBlockToolForBudget,
  toolBudgetBlockedMessage,
  toolBudgetSoftNudge,
  validateAcceptanceReport,
  validateStructuredOutputValue
} from "./chunk-LWH7IGI3.js";
import {
  INTERCOM_SESSION_IDENTITY_EVENT
} from "./chunk-JEZOSEWG.js";

// src/runs/shared/subagent-prompt-runtime.ts
import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { declarationsEqual, getCurrentSystemMessage, getCurrentTools } from "@earendil-works/pi-ai";

// src/runs/shared/runtime-acknowledged-extensions.ts
var RUNTIME_EXTENSION_ACK_EVENT = "subagent:acknowledge-extension";
var MAX_RUNTIME_ACKNOWLEDGED_EXTENSION_IDS = 32;
var MAX_RUNTIME_ACKNOWLEDGED_EXTENSION_ID_LENGTH = 128;
function isRuntimeAcknowledgedExtensionId(value) {
  return typeof value === "string" && value.length > 0 && value.length <= MAX_RUNTIME_ACKNOWLEDGED_EXTENSION_ID_LENGTH && /^[A-Za-z0-9._:@+-]+$/.test(value) && !value.includes("..") && !value.includes("/") && !value.includes("\\");
}
function projectRuntimeAcknowledgedExtensions(ids) {
  const unique = [];
  const seen = /* @__PURE__ */ new Set();
  for (const id of ids) {
    if (!isRuntimeAcknowledgedExtensionId(id) || seen.has(id)) continue;
    seen.add(id);
    unique.push(id);
  }
  if (unique.length === 0) return void 0;
  return {
    version: 1,
    source: "child-runtime",
    ids: unique.slice(0, MAX_RUNTIME_ACKNOWLEDGED_EXTENSION_IDS),
    omitted: Math.max(0, unique.length - MAX_RUNTIME_ACKNOWLEDGED_EXTENSION_IDS)
  };
}

// src/runs/shared/tool-availability.ts
function formatChildToolDiagnostic(diagnostic, options = {}) {
  const subject = diagnostic.agent ? `Agent '${diagnostic.agent}'` : "Subagent";
  if (diagnostic.undeclared?.length) {
    const uncallable = diagnostic.uncallable?.length ? ` and added ${diagnostic.uncallable.join(", ")}, which this child cannot call` : "";
    return [
      `${subject} declares tools: ${diagnostic.required.join(", ")}, but an extension loaded in this child replaced the tools sent to the model: it left out ${diagnostic.undeclared.join(", ")}${uncallable}.`,
      "The `tools` field is a strict allowlist. Set `extensions: []` or list only the extensions this child needs, or omit `tools` to use that extension's tool surface."
    ].join("\n");
  }
  if (options.host === "parent") {
    return [
      `${subject} ran as a foreground child, which never loads the parent's ambient extensions, and these child tools were unavailable: ${diagnostic.missing.join(", ")}.`,
      "The `tools` field is a strict allowlist; it does not load extension code.",
      ...diagnostic.missingMcpDirectTools?.length ? [`MCP direct tools missing from the child registry: ${diagnostic.missingMcpDirectTools.join(", ")}.`] : [],
      "MCP tools require background children (`async: true`) because only they load ambient extensions.",
      "For extension tools a foreground child can load, add the provider path to `subagentOnlyExtensions` (child-only), `extensions`, or as a path-like entry in `tools`, while keeping each registered tool name in `tools`."
    ].join("\n");
  }
  return [
    `${subject} requested unavailable child tools: ${diagnostic.missing.join(", ")}.`,
    "The `tools` field is a strict allowlist; it does not load extension code.",
    ...diagnostic.missingMcpDirectTools?.length ? [`Resolved MCP direct tools missing from the child registry: ${diagnostic.missingMcpDirectTools.join(", ")}. Resolved names must match what the host or pi-mcp-adapter registers; check the MCP direct-tool registration before treating this as a tool-call failure.`] : [],
    "For extension tools, add the provider path to `subagentOnlyExtensions` (child-only), `extensions`, or as a path-like entry in `tools`, while keeping each registered tool name in `tools`.",
    "For MCP tools, verify the MCP adapter configuration and selected tool names. For builtin tools, verify the name against the installed Pi version."
  ].join("\n");
}

// src/watchdog/register-child.ts
function childResolvedConfig(config) {
  return {
    ...DEFAULT_WATCHDOG_CONFIG,
    enabled: true,
    agentEndTimeoutMs: config.agentEndTimeoutMs,
    maxWarnings: config.maxWarnings,
    main: {
      enabled: true,
      ...config.model ? { model: config.model } : {},
      ...config.thinking !== void 0 ? { thinking: config.thinking } : {}
    },
    stalemateRepeats: config.stalemateRepeats,
    cadence: { ...config.cadence },
    children: {
      ...DEFAULT_WATCHDOG_CONFIG.children,
      watchdogTailTimeoutMs: config.watchdogTailTimeoutMs
    },
    lsp: { ...config.lsp }
  };
}
function childWarningDetails(details, config) {
  return {
    ...details,
    source: details.source === "lsp" ? "lsp" : "child",
    ...config.agent ? { agent: config.agent } : {},
    ...config.runId ? { runId: config.runId } : {}
  };
}
function registerChildWatchdog(pi, childConfig, writeStatus, structuredTerminal) {
  if (!childConfig) return void 0;
  if (!writeStatus) throw new Error("Child watchdog status sink is missing; the host must pass ChildRuntimeConfig.watchdogStatus.");
  let currentContext;
  let diffBaseline;
  let agentSettled = false;
  let seq = 0;
  const emitStatus = (phase, reason, warning) => {
    writeStatus({
      type: CHILD_WATCHDOG_STATUS_EVENT,
      ...childConfig.runId ? { runId: childConfig.runId } : {},
      ...childConfig.agent ? { agent: childConfig.agent } : {},
      ...childConfig.childIndex !== void 0 ? { childIndex: childConfig.childIndex, stepIndex: childConfig.childIndex } : {},
      seq: ++seq,
      phase,
      ts: Date.now(),
      ...reason ? { reason } : {},
      ...warning ? { warning } : {}
    });
  };
  const resolved = childResolvedConfig(childConfig);
  const runtime = new MainWatchdogRuntime({
    resolveConfig: () => ({ ok: true, config: resolved, errors: [], sources: [{ scope: "session", exists: true }] }),
    review: createMainWatchdogReview(() => currentContext, { getThinkingLevel: () => pi.getThinkingLevel(), diffBaseline: () => diffBaseline }),
    reviewDescription: "child model review",
    reviewChangesOnly: true,
    displayWarning: (details, options) => {
      const childDetails = childWarningDetails(details, childConfig);
      emitStatus("reviewing", void 0, { severity: childDetails.severity, importance: childDetails.importance, category: childDetails.category, summary: childDetails.summary, evidence: childDetails.evidence, recommendedAction: childDetails.recommendedAction, ...childDetails.displayedAt ? { displayedAt: childDetails.displayedAt } : {}, addressed: false, stalemate: childDetails.state === "stalemate" });
      const message = createWatchdogWarningMessage(childDetails, { display: true, details: childDetails });
      if (agentSettled) pi.appendEntry(SUBAGENT_WATCHDOG_WARNING_TYPE, childDetails);
      else pi.sendMessage(message, options);
    },
    displayUserWarning: (details) => {
      const childDetails = childWarningDetails(details, childConfig);
      emitStatus("reviewing", void 0, { severity: childDetails.severity, importance: childDetails.importance, category: childDetails.category, summary: childDetails.summary, evidence: childDetails.evidence, recommendedAction: childDetails.recommendedAction, ...childDetails.displayedAt ? { displayedAt: childDetails.displayedAt } : {}, addressed: false, stalemate: childDetails.state === "stalemate" });
      pi.appendEntry(SUBAGENT_WATCHDOG_WARNING_TYPE, childDetails);
    }
  });
  const rememberContext = (ctx) => {
    currentContext = ctx;
  };
  const onRuntimeEvent = pi.on;
  onRuntimeEvent("session_start", (_event, ctx) => {
    rememberContext(ctx);
    diffBaseline = startWatchdogDiffBaselineCapture(ctx.cwd);
    runtime.bindSession(ctx);
    emitStatus("idle");
  });
  onRuntimeEvent("before_agent_start", (event, ctx) => {
    agentSettled = false;
    rememberContext(ctx);
    runtime.handleBeforeAgentStart(event, ctx);
  });
  onRuntimeEvent("turn_end", (event, ctx) => {
    rememberContext(ctx);
    runtime.handleTurnEnd(event, ctx, structuredTerminal?.captured === true);
  });
  onRuntimeEvent("tool_result", (_event, ctx) => {
    rememberContext(ctx);
    runtime.handleToolResult(ctx);
  });
  onRuntimeEvent("agent_end", async (event, ctx) => {
    rememberContext(ctx);
    emitStatus("reviewing");
    await runtime.handleAgentEnd(event, ctx);
    const snapshot = runtime.getSnapshot(ctx.cwd);
    if (snapshot.status === "failed") emitStatus("failed", snapshot.lastError);
    else if (snapshot.status === "stale") emitStatus("stale", "review stale");
    else emitStatus("idle");
  });
  onRuntimeEvent("agent_settled", () => {
    agentSettled = true;
  });
  onRuntimeEvent("session_shutdown", () => {
    currentContext = void 0;
    runtime.dispose();
    emitStatus("idle");
  });
  return runtime;
}

// src/watchdog/permission-arbiter.ts
import { Agent } from "@earendil-works/pi-agent-core";
import { convertToLlm } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
var PermissionDecisionParams = Type.Object({
  decision: Type.String({ enum: ["approve", "deny"] }),
  reason: Type.String({ description: "One concise reason for this exact decision." })
}, { additionalProperties: false });
function conciseReason(value) {
  const trimmed = value.trim();
  return trimmed ? trimmed.slice(0, 500) : "Watchdog returned an empty reason.";
}
function createWatchdogPermissionArbiter(options = {}) {
  return async (request) => {
    const preview = permissionArgsPreview(request.args);
    const createdAt = Date.now();
    const auditBase = { type: "permission.request", createdAt, toolName: request.toolName, preview, matchedRule: "ask", decisionSource: "watchdog" };
    appendPermissionAudit(request.auditPath, auditBase);
    let completed = false;
    const finish = (approved, reason, decision2) => {
      const concise = conciseReason(reason);
      if (completed) return { approved, reason: concise, source: "watchdog" };
      completed = true;
      appendPermissionAudit(request.auditPath, {
        type: "permission.decision",
        createdAt: Date.now(),
        requestCreatedAt: createdAt,
        toolName: request.toolName,
        decision: decision2,
        approved,
        decisionSource: "watchdog",
        reason: concise
      });
      return { approved, reason: concise, source: "watchdog" };
    };
    let childConfig;
    try {
      childConfig = decodeChildWatchdogConfig(request.rawWatchdogConfig);
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      return finish(false, `Watchdog permission arbiter configuration is invalid: ${reason}`, "unavailable");
    }
    if (!childConfig) return finish(false, "Watchdog permission arbiter is unavailable because the child watchdog is disabled.", "unavailable");
    if (request.signal?.aborted || request.ctx.signal?.aborted) return finish(false, "Watchdog permission decision was cancelled.", "cancelled");
    let decision;
    const tool = {
      name: "watchdog_permission_decision",
      label: "Watchdog permission decision",
      description: "Approve or deny this exact child tool call. Call exactly once.",
      parameters: PermissionDecisionParams,
      executionMode: "sequential",
      async execute(_toolCallId, params) {
        if (!decision) decision = params;
        return { content: [{ type: "text", text: "Permission decision recorded." }], details: { recorded: true } };
      }
    };
    let timeout;
    let agent;
    let abort;
    try {
      const run = async () => {
        const config = childResolvedConfig(childConfig);
        const selection = await resolveWatchdogReviewModel(request.ctx, config);
        const auth = selection.auth;
        const sessionId = request.ctx.sessionManager.getSessionId();
        const baseStreamFn = options.streamFn ?? ((model, context, streamOptions) => request.ctx.modelRegistry.streamSimple(model, context, streamOptions));
        const streamFn = (model, context, streamOptions) => baseStreamFn(model, context, {
          ...streamOptions,
          ...auth.apiKey ? { apiKey: auth.apiKey } : {},
          env: auth.env || streamOptions?.env ? { ...auth.env ?? {}, ...streamOptions?.env ?? {} } : void 0,
          headers: { ...opencodeSessionHeaders(model, sessionId), ...streamOptions?.headers ?? {}, ...auth.headers ?? {} }
        });
        const systemPrompt = [
          "You are the pi-subagents watchdog permission arbiter.",
          "Decide only whether this exact non-bash child tool call should proceed.",
          "Call watchdog_permission_decision exactly once with approve or deny and a concise reason.",
          "Deny when uncertain. Do not produce freeform advice or ask the parent orchestrator.",
          "",
          formatWatchdogCwdSection(request.ctx.cwd)
        ].join("\n");
        const tools = [tool];
        agent = new Agent({
          sessionId,
          initialState: {
            systemPrompt,
            model: selection.model,
            thinkingLevel: selection.thinkingLevel,
            tools
          },
          convertToLlm,
          ...agentStreamOptions(streamFn),
          getApiKey: (providerName) => providerName === selection.model.provider ? auth.apiKey : void 0,
          beforeToolCall: async ({ toolCall }) => toolCall.name === tool.name ? void 0 : { block: true, reason: `Permission arbiter tool '${toolCall.name}' is not allowed.` },
          toolExecution: "sequential"
        });
        await agent.prompt(`Tool: ${request.toolName}
Redacted arguments: ${preview}`);
        if (!decision) return finish(false, "Watchdog permission arbiter returned no decision.", "malformed");
        const approved = decision.decision === "approve";
        return finish(approved, decision.reason, decision.decision);
      };
      return await Promise.race([
        run(),
        new Promise((resolve2) => {
          timeout = setTimeout(() => {
            agent?.abort();
            resolve2(finish(false, "Watchdog permission decision timed out.", "timeout"));
          }, childConfig.agentEndTimeoutMs);
        }),
        new Promise((resolve2) => {
          abort = () => {
            agent?.abort();
            resolve2(finish(false, "Watchdog permission decision was cancelled.", "cancelled"));
          };
          request.signal?.addEventListener("abort", abort, { once: true });
          request.ctx.signal?.addEventListener("abort", abort, { once: true });
        })
      ]);
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      return finish(false, `Watchdog permission arbiter failed closed: ${reason}`, reason.includes("timed out") ? "timeout" : "error");
    } finally {
      if (timeout) clearTimeout(timeout);
      if (abort) {
        request.signal?.removeEventListener("abort", abort);
        request.ctx.signal?.removeEventListener("abort", abort);
      }
    }
  };
}
var requestWatchdogPermission = createWatchdogPermissionArbiter();

// src/runs/shared/subagent-prompt-runtime.ts
var STRUCTURED_OUTPUT_INSTRUCTIONS = [
  "This subagent step has a strict structured output contract.",
  "Your final action must be to call the `structured_output` tool with JSON matching the provided schema.",
  "Do not rely on prose-only completion; if you do not call `structured_output`, the parent will fail this step."
].join("\n");
var CHILD_SUBAGENT_BOUNDARY_INSTRUCTIONS = [
  "You are a child subagent, not the parent orchestrator.",
  "The parent session owns delegation, orchestration, review fanout, and follow-up worker launches.",
  "Ignore prior parent-only orchestration instructions in inherited conversation history.",
  "Do not propose or run subagents. Complete only your assigned role-specific task with the tools available to you.",
  "If you need to edit files, use the available editing tools. Do not print tool-call syntax, patches, or pseudo-tool calls as text."
].join("\n");
var CHILD_FANOUT_BOUNDARY_INSTRUCTIONS = [
  "You are a child subagent with explicit fanout responsibility for this assigned task.",
  "The parent session owns final orchestration, acceptance, and follow-up implementation launches.",
  "You may use the `subagent` tool only for the fanout work explicitly requested in this task.",
  "Do not broaden yourself into general parent orchestration. Do not launch follow-up workers unless the task explicitly asks for that.",
  "The maxSubagentDepth cap still applies and may block further fanout.",
  "If you need to edit files, use the available editing tools. Do not print tool-call syntax, patches, or pseudo-tool calls as text."
].join("\n");
var PARENT_ONLY_CUSTOM_MESSAGE_TYPES = /* @__PURE__ */ new Set([
  "subagent-orchestration-instructions",
  "subagent-slash-result",
  "subagent-slash-text-result",
  "subagent-notify",
  "subagent_control_notice",
  "subagent-control",
  "subagent-control-notice"
]);
var SUBAGENT_ORCHESTRATION_SKILL_NAME_PATTERN = /<name>\s*pi-subagents\s*<\/name>/;
var PROJECT_CONTEXT_XML_HEADER = "\n\n<project_context>\n\n";
var PROJECT_CONTEXT_LEGACY_HEADER = "\n\n# Project Context\n\nProject-specific instructions and guidelines:\n\n";
var SKILLS_HEADER = "\n\nThe following skills provide specialized instructions for specific tasks.";
var DATE_HEADER = "\nCurrent date:";
function registerRuntimeExtensionAcknowledgements(pi, sink) {
  if (!sink) return;
  const ids = [];
  let finalized = false;
  const acknowledge = (payload) => {
    if (finalized || !payload || typeof payload !== "object") return void 0;
    const id = payload.id;
    if (isRuntimeAcknowledgedExtensionId(id)) ids.push(id);
    return void 0;
  };
  const finalize = () => {
    if (finalized) return void 0;
    finalized = true;
    sink(ids);
    return void 0;
  };
  try {
    const events = pi.events;
    events?.on?.(RUNTIME_EXTENSION_ACK_EVENT, acknowledge);
    const onRuntimeEvent = pi.on;
    onRuntimeEvent("agent_end", finalize);
    onRuntimeEvent("session_shutdown", finalize);
  } catch {
  }
}
function findSectionEnd(prompt, startIndex, nextHeaders) {
  let endIndex = prompt.length;
  for (const header of nextHeaders) {
    const index = prompt.indexOf(header, startIndex);
    if (index !== -1 && index < endIndex) {
      endIndex = index;
    }
  }
  return endIndex;
}
function stripProjectContext(prompt) {
  const xmlStartIndex = prompt.indexOf(PROJECT_CONTEXT_XML_HEADER);
  if (xmlStartIndex !== -1) {
    const closingTag = "</project_context>";
    const closingIndex = prompt.indexOf(closingTag, xmlStartIndex + PROJECT_CONTEXT_XML_HEADER.length);
    if (closingIndex !== -1) {
      return `${prompt.slice(0, xmlStartIndex)}${prompt.slice(closingIndex + closingTag.length)}`;
    }
  }
  const legacyStartIndex = prompt.indexOf(PROJECT_CONTEXT_LEGACY_HEADER);
  if (legacyStartIndex === -1) return prompt;
  const endIndex = findSectionEnd(prompt, legacyStartIndex + PROJECT_CONTEXT_LEGACY_HEADER.length, [SKILLS_HEADER, DATE_HEADER]);
  return `${prompt.slice(0, legacyStartIndex)}${prompt.slice(endIndex)}`;
}
var GLOBAL_CONTEXT_FILE_NAMES = /* @__PURE__ */ new Set(["agents.md", "agents.override.md", "claude.md"]);
function canonicalDirectory(dir) {
  try {
    return fs.realpathSync(dir);
  } catch {
    return path.resolve(dir);
  }
}
function expandContextPath(filePath) {
  const home = process.env.HOME ?? process.env.USERPROFILE;
  return filePath === "~" ? home ?? filePath : /^~[\\/]/.test(filePath) ? path.join(home ?? "~", filePath.slice(2)) : filePath;
}
function isContextFilePath(filePath) {
  return GLOBAL_CONTEXT_FILE_NAMES.has(path.basename(expandContextPath(filePath)).toLowerCase());
}
function isGlobalContextFile(filePath) {
  const expanded = expandContextPath(filePath);
  if (!isContextFilePath(filePath)) return false;
  return canonicalDirectory(path.dirname(expanded)) === canonicalDirectory(getAgentDir());
}
function stripGlobalInstructionsFromXmlContext(context) {
  const block = /<project_instructions\s+path=(["'])(.*?)\1\s*>[\s\S]*?<\/project_instructions>\s*/gi;
  return context.replace(block, (match, _quote, filePath) => isGlobalContextFile(filePath) ? "" : match);
}
function stripGlobalInstructionsFromLegacyContext(context) {
  const sections = [...context.matchAll(/^## ([^\r\n]+)(?:\r?\n|$)/gm)].filter((match) => isContextFilePath(match[1].trim()));
  let rewritten = "";
  let cursor = 0;
  for (let index = 0; index < sections.length; index++) {
    const section = sections[index];
    const start = section.index;
    const end = sections[index + 1]?.index ?? context.length;
    rewritten += context.slice(cursor, start);
    if (!isGlobalContextFile(section[1].trim())) rewritten += context.slice(start, end);
    cursor = end;
  }
  return `${rewritten}${context.slice(cursor)}`;
}
function stripGlobalContext(prompt) {
  const rewrittenXml = prompt.replace(/<project_context>[\s\S]*?<\/project_context>/gi, (context) => {
    const rewritten = stripGlobalInstructionsFromXmlContext(context);
    return /<project_instructions\b/i.test(rewritten) ? rewritten : "";
  });
  const legacyStartIndex = rewrittenXml.indexOf(PROJECT_CONTEXT_LEGACY_HEADER);
  if (legacyStartIndex === -1) return rewrittenXml;
  const legacyEndIndex = findSectionEnd(rewrittenXml, legacyStartIndex + PROJECT_CONTEXT_LEGACY_HEADER.length, [SKILLS_HEADER, DATE_HEADER]);
  const legacyContext = rewrittenXml.slice(legacyStartIndex, legacyEndIndex);
  return `${rewrittenXml.slice(0, legacyStartIndex)}${stripGlobalInstructionsFromLegacyContext(legacyContext)}${rewrittenXml.slice(legacyEndIndex)}`;
}
function stripInheritedSkills(prompt) {
  const startIndex = prompt.indexOf(SKILLS_HEADER);
  if (startIndex === -1) return prompt;
  const endIndex = findSectionEnd(prompt, startIndex + SKILLS_HEADER.length, [DATE_HEADER]);
  return `${prompt.slice(0, startIndex)}${prompt.slice(endIndex)}`;
}
function stripSubagentOrchestrationSkill(prompt) {
  return prompt.replace(/\n{0,2}<skill\s+name=["']pi-subagents["'][^>]*>[\s\S]*?<\/skill>\n{0,2}/g, "\n\n").replace(/[ \t]*<skill>\s*[\s\S]*?<\/skill>\s*/g, (block) => SUBAGENT_ORCHESTRATION_SKILL_NAME_PATTERN.test(block) ? "" : block);
}
function stripChildBoundaryInstructions(prompt) {
  let rewritten = prompt;
  for (const instructions of [CHILD_SUBAGENT_BOUNDARY_INSTRUCTIONS, CHILD_FANOUT_BOUNDARY_INSTRUCTIONS, STRUCTURED_OUTPUT_INSTRUCTIONS]) {
    rewritten = rewritten.split(`

${instructions}`).join("").split(instructions).join("");
  }
  return rewritten.replace(/^(?:[ \t]*\r?\n)+/, "");
}
function stripInheritedPromptText(prompt, options) {
  let rewritten = prompt;
  if (!options.inheritProjectContext) {
    rewritten = stripProjectContext(rewritten);
  }
  if (!options.inheritGlobalContext) {
    rewritten = stripGlobalContext(rewritten);
  }
  if (!options.inheritSkills) {
    rewritten = stripInheritedSkills(rewritten);
  }
  return stripChildBoundaryInstructions(stripSubagentOrchestrationSkill(rewritten));
}
function childBoundary(options) {
  const boundary = options.fanoutChild ? CHILD_FANOUT_BOUNDARY_INSTRUCTIONS : CHILD_SUBAGENT_BOUNDARY_INSTRUCTIONS;
  return options.structuredOutput ? `${boundary}

${STRUCTURED_OUTPUT_INSTRUCTIONS}` : boundary;
}
function appendChildBoundary(prompt, options) {
  return `${stripChildBoundaryInstructions(prompt)}

${childBoundary(options)}`;
}
function rewriteSubagentPrompt(prompt, options) {
  return appendChildBoundary(stripInheritedPromptText(prompt, options), options);
}
function filterChildPromptOptions(options, inherited) {
  if (!inherited.inheritProjectContext) options.contextFiles = [];
  else if (!inherited.inheritGlobalContext) options.contextFiles = options.contextFiles.filter((file) => !isGlobalContextFile(file.path));
  options.skills = inherited.inheritSkills ? options.skills.filter((skill) => skill.name !== "pi-subagents") : [];
  if (options.customPrompt) options.customPrompt = stripInheritedPromptText(options.customPrompt, inherited);
  if (options.appendSystemPrompt) options.appendSystemPrompt = stripInheritedPromptText(options.appendSystemPrompt, inherited);
}
function rewritesChildPrompt(config) {
  return config.inheritProjectContext !== void 0 || config.inheritGlobalContext !== void 0 || config.inheritSkills !== void 0 || Boolean(config.fanoutChild);
}
function registerDeclaredToolCheck(pi, config, required) {
  pi.on("context_with_system", (event, ctx) => {
    const declared = new Set(getCurrentTools(event.messages).map((tool) => tool.name));
    if (required.every((name) => declared.has(name))) return void 0;
    const active = new Set(pi.getActiveTools());
    const undeclared = required.filter((name) => active.has(name) && !declared.has(name));
    if (undeclared.length === 0) return void 0;
    const registered = new Set(pi.getAllTools().map((tool) => tool.name));
    const uncallable = config.forkCacheKey ? [] : [...declared].filter((name) => !active.has(name));
    config.toolDiagnostic?.({
      ...config.agent ? { agent: config.agent } : {},
      required: [...required],
      available: [...registered],
      missing: [],
      undeclared,
      ...uncallable.length > 0 ? { uncallable } : {}
    });
    ctx.abort();
    return void 0;
  });
}
function registerSubagentPromptBoundary(pi, config) {
  if (config.requiredTools) registerDeclaredToolCheck(pi, config, config.requiredTools);
  if (!rewritesChildPrompt(config)) return;
  if (config.forkCacheKey) return;
  pi.on("before_agent_start", (event) => {
    const finalized = appendChildBoundary(event.systemPrompt, { fanoutChild: config.fanoutChild, structuredOutput: Boolean(config.structuredOutput) });
    return finalized === event.systemPrompt ? void 0 : { systemPrompt: finalized };
  });
}
function isParentOnlySubagentMessage(message) {
  const m = message;
  if (m?.role !== "custom" || typeof m.customType !== "string") return false;
  if (m.customType === SUBAGENT_WATCHDOG_WARNING_TYPE) return true;
  return PARENT_ONLY_CUSTOM_MESSAGE_TYPES.has(m.customType);
}
function isSubagentToolResultMessage(message) {
  const m = message;
  return m?.role === "toolResult" && m.toolName === "subagent";
}
function isSubagentToolCallBlock(block) {
  const b = block;
  return b?.type === "toolCall" && b.name === "subagent";
}
var PORTABLE_TOOL_ID_PATTERN = /^[a-zA-Z0-9_-]+$/;
var MAX_PORTABLE_TOOL_ID_LENGTH = 64;
var COMPOSITE_TOOL_ID_APIS = /* @__PURE__ */ new Set([
  "azure-openai-responses",
  "cursor-native",
  "openai-completions",
  "openai-responses"
]);
var PROMPT_CACHE_KEY_APIS = /* @__PURE__ */ new Set([
  "azure-openai-responses",
  "openai-codex-responses",
  "openai-completions",
  "openai-responses"
]);
var isSystemMessage = (message) => message.role === "system";
var writtenBefore = (message, forkedAt) => typeof message.timestamp === "number" && message.timestamp < forkedAt;
var promptText = (message) => typeof message?.content === "string" ? message.content : (message?.content ?? []).map((block) => block.text).join("");
function systemMessagesBefore(messages, forkedAt) {
  return messages.filter((message) => isSystemMessage(message) && writtenBefore(message, forkedAt));
}
function modelBefore(messages, forkedAt) {
  for (let index = messages.length - 1; index >= 0; index--) {
    const message = messages[index];
    if (message.role !== "assistant" || !writtenBefore(message, forkedAt)) continue;
    if (typeof message.provider !== "string" || typeof message.api !== "string" || typeof message.model !== "string") return void 0;
    return { provider: message.provider, api: message.api, model: message.model };
  }
  return void 0;
}
var LOADOUT_SECTIONS = /* @__PURE__ */ new Set(["tools", "rules", "docs", "skills", "advertised_subagents", "mcp_servers", "project_context"]);
function projectInstructionBlocks(section) {
  const blocks = /* @__PURE__ */ new Map();
  for (const match of (section ?? "").matchAll(/<project_instructions\s+path=(["'])(.*?)\1\s*>[\s\S]*?<\/project_instructions>/gi)) blocks.set(match[2], match[0]);
  return blocks;
}
function forkInstructions(input) {
  const parent = getCurrentSystemMessage(input.parent);
  const child = getCurrentSystemMessage(input.child);
  const parts = [
    "The system prompt and tool list of this conversation are the parent session's, sent unchanged so this request reuses the parent's prompt cache. The instructions below are yours and take precedence over the parent's role.",
    `Tools you can call: ${getCurrentTools(input.child).map((tool) => tool.name).join(", ") || "none"}. Any other declared tool belongs to the parent session and fails if called.`
  ];
  const ownPrompt = promptText(getCurrentSystemMessage(input.own));
  if (ownPrompt.length > 0) parts.push(ownPrompt);
  for (const [name, value] of Object.entries(child?.sections ?? {})) {
    if (!LOADOUT_SECTIONS.has(name) && value && parent?.sections?.[name] !== value) parts.push(value);
  }
  const parentFiles = projectInstructionBlocks(parent?.sections?.project_context);
  const missingFiles = [...projectInstructionBlocks(child?.sections?.project_context)].filter(([filePath]) => !parentFiles.has(filePath)).map(([, block]) => block);
  if (missingFiles.length > 0) parts.push(["Project instructions for your working folder, which the parent's prompt does not include:", ...missingFiles].join("\n\n"));
  if (input.boundary) parts.push(input.boundary);
  return `<subagent_instructions>
${parts.join("\n\n")}
</subagent_instructions>`;
}
function prependText(message, text) {
  const content = message.content;
  if (typeof content === "string") return { ...message, content: `${text}

${content}` };
  if (Array.isArray(content)) return { ...message, content: [{ type: "text", text }, ...content] };
  return message;
}
function projectForkRequest(messages, inherited, forkedAt, options = {}) {
  const own = (message) => !writtenBefore(message, forkedAt);
  if (inherited.length === 0 || !messages.some((message) => !isSystemMessage(message) && !own(message))) {
    if (!options.boundary) return messages;
    const at2 = messages.findIndex((message) => !isSystemMessage(message));
    const section = { role: "system", content: "", sections: { subagent_boundary: `<subagent_boundary>
${options.boundary}
</subagent_boundary>` }, timestamp: forkedAt };
    return at2 === -1 ? [...messages, section] : [...messages.slice(0, at2), section, ...messages.slice(at2)];
  }
  const instructions = forkInstructions({ parent: inherited, child: messages, own: messages.filter((message) => isSystemMessage(message) && own(message)), boundary: options.boundary });
  const parentTools = new Map(getCurrentTools(inherited).map((tool) => [tool.name, tool]));
  const childTools = getCurrentTools(messages).filter((tool) => {
    const parentTool = parentTools.get(tool.name);
    return !parentTool || !declarationsEqual(parentTool, tool);
  });
  const redefined = childTools.filter((tool) => parentTools.has(tool.name)).map((tool) => ({ name: tool.name }));
  const sentInherited = messages.filter((message) => isSystemMessage(message) && !own(message));
  const uncollapsed = sentInherited.length === inherited.length && sentInherited.every((message, index) => JSON.stringify(message) === JSON.stringify(inherited[index]));
  const conversation = messages.filter((message) => !isSystemMessage(message));
  const head = getCurrentSystemMessage(inherited);
  const next = uncollapsed ? messages.filter((message) => !isSystemMessage(message) || !own(message)) : [...head ? [head] : [], ...conversation];
  const firstOwn = next.findIndex((message) => !isSystemMessage(message) && own(message));
  const task = next.findIndex((message) => message.role === "user" && own(message));
  const additions = [];
  if (childTools.length > 0) additions.push({ role: "system", content: "", ...redefined.length > 0 ? { toolsRemoved: redefined } : {}, toolsAdded: childTools, timestamp: forkedAt });
  if (task === -1) additions.push({ role: "system", content: "", sections: { subagent_instructions: instructions }, timestamp: forkedAt });
  else next[task] = prependText(next[task], instructions);
  const at = firstOwn === -1 ? next.length : firstOwn;
  return [...next.slice(0, at), ...additions, ...next.slice(at)];
}
function applyForkSessionAffinity(headers, model, parentSessionId, parentModel) {
  const parent = parentSessionId?.trim();
  if (!headers || !parent || model?.api !== "anthropic-messages") return;
  if (!parentModel || parentModel.provider !== model.provider || parentModel.api !== model.api || parentModel.model !== model.id) return;
  const compat = model.compat;
  if (!compat?.sendSessionAffinityHeaders) return;
  headers[compat.sessionAffinityFormat === "openrouter" ? "x-session-id" : "x-session-affinity"] = parent;
}
function rewriteForkCacheProviderRequest(event, ctx, forkCacheKey) {
  const key = forkCacheKey?.trim();
  if (!key || !PROMPT_CACHE_KEY_APIS.has(ctx?.model?.api ?? "")) return void 0;
  if (!event || typeof event !== "object") return void 0;
  const payload = event.payload;
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) return void 0;
  if (typeof payload.prompt_cache_key !== "string") return void 0;
  return { ...payload, prompt_cache_key: key };
}
function portableToolId(id, preserveBoundedCompositeToolIds = false) {
  if (PORTABLE_TOOL_ID_PATTERN.test(id) && id.length <= MAX_PORTABLE_TOOL_ID_LENGTH) return id;
  if (preserveBoundedCompositeToolIds) {
    const parts = id.split("|");
    if (parts.length === 2 && parts.every((part) => PORTABLE_TOOL_ID_PATTERN.test(part) && part.length <= MAX_PORTABLE_TOOL_ID_LENGTH)) return id;
  }
  const encoded = `tool_${Buffer.from(id).toString("base64url") || "empty"}`;
  if (encoded.length <= MAX_PORTABLE_TOOL_ID_LENGTH) return encoded;
  return `tool_${createHash("sha256").update(id).digest("base64url")}`;
}
function sanitizeToolHistoryMessage(message, preserveBoundedCompositeToolIds = false) {
  const m = message;
  if (m?.role === "toolResult" && typeof m.toolCallId === "string") {
    const toolCallId = portableToolId(m.toolCallId, preserveBoundedCompositeToolIds);
    return toolCallId === m.toolCallId ? message : { ...m, toolCallId };
  }
  if (m?.role !== "assistant" || !Array.isArray(m.content)) return message;
  let changed = false;
  const content = m.content.map((block) => {
    const b = block;
    if (b?.type !== "toolCall" || typeof b.id !== "string") return block;
    const id = portableToolId(b.id, preserveBoundedCompositeToolIds);
    if (id === b.id) return block;
    changed = true;
    return { ...b, id };
  });
  return changed ? { ...m, content } : message;
}
function stripAssistantSubagentToolCallBlocks(message) {
  const m = message;
  if (m?.role !== "assistant" || !Array.isArray(m.content)) return message;
  const filteredContent = m.content.filter((block) => !isSubagentToolCallBlock(block));
  if (filteredContent.length === m.content.length) return message;
  if (filteredContent.length === 0) return void 0;
  return { ...m, content: filteredContent };
}
function stripParentOnlySubagentMessages(messages, options = {}) {
  const preserveCurrentFanoutToolHistory = options.preserveFanoutToolHistory === true;
  const sanitizeToolIds = options.sanitizeToolIds ?? true;
  const inheritedBefore = options.inheritedBefore;
  const inherited = (message) => inheritedBefore !== void 0 && typeof message?.timestamp === "number" && message.timestamp < inheritedBefore;
  let changed = false;
  const filtered = [];
  for (const message of messages) {
    const keep = inherited(message);
    if (!keep && (isParentOnlySubagentMessage(message) || !preserveCurrentFanoutToolHistory && isSubagentToolResultMessage(message))) {
      changed = true;
      continue;
    }
    const stripped = keep || preserveCurrentFanoutToolHistory ? message : stripAssistantSubagentToolCallBlocks(message);
    if (stripped === void 0) {
      changed = true;
      continue;
    }
    const sanitized = sanitizeToolIds ? sanitizeToolHistoryMessage(stripped, options.preserveBoundedCompositeToolIds === true) : stripped;
    if (stripped !== message || sanitized !== stripped) changed = true;
    filtered.push(sanitized);
  }
  return changed ? filtered : messages;
}
function registerPermissionGate(pi, permissions, childWatchdog, requestPermission = requestWatchdogPermission) {
  const rules = permissions?.rules;
  if (!rules || Object.keys(rules).length === 0) return;
  const rawWatchdogConfig = childWatchdog ? JSON.stringify(childWatchdog) : void 0;
  const timeoutMs = childWatchdog?.agentEndTimeoutMs ?? 3e4;
  const onRuntimeEvent = pi.on;
  onRuntimeEvent("tool_call", async (event, ctx) => {
    const toolName = typeof event.toolName === "string" ? event.toolName : "tool";
    const decision = permissionDecision(rules, toolName);
    if (decision === "allow") return void 0;
    if (decision === "deny") return { block: true, reason: `Blocked by pi-subagents permission rule: '${toolName}' is denied.` };
    if (ctx.signal?.aborted) return { block: true, reason: "Blocked by pi-subagents permission rule: Watchdog permission decision was cancelled." };
    let timeout;
    let abort;
    let result;
    try {
      result = await Promise.race([
        requestPermission({
          ctx,
          toolName,
          args: event.input ?? {},
          rawWatchdogConfig,
          auditPath: permissions.auditPath,
          ...ctx.signal ? { signal: ctx.signal } : {}
        }),
        new Promise((resolve2) => {
          if (!ctx.signal) return;
          abort = () => resolve2({ approved: false, reason: "Watchdog permission decision was cancelled.", source: "watchdog" });
          ctx.signal.addEventListener("abort", abort, { once: true });
        }),
        new Promise((_, reject) => {
          timeout = setTimeout(() => reject(new Error(`Watchdog permission decision timed out after ${timeoutMs}ms.`)), timeoutMs);
        })
      ]);
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      return { block: true, reason: `Blocked by pi-subagents permission rule: Watchdog permission arbiter failed closed: ${reason}` };
    } finally {
      if (timeout) clearTimeout(timeout);
      if (abort) ctx.signal?.removeEventListener("abort", abort);
    }
    if (result.approved) return void 0;
    return { block: true, reason: `Blocked by pi-subagents permission rule: ${result.reason}` };
  });
}
function registerToolBudget(pi, budget) {
  if (!budget) return;
  let toolCount = 0;
  let softNudged = false;
  const sendUserMessage = pi.sendUserMessage;
  const onRuntimeEvent = pi.on;
  onRuntimeEvent("tool_call", (event) => {
    const toolName = typeof event.toolName === "string" ? event.toolName : "tool";
    toolCount++;
    if (budget.soft !== void 0 && toolCount >= budget.soft && !softNudged) {
      softNudged = true;
      try {
        sendUserMessage?.(toolBudgetSoftNudge(budget, toolCount), { deliverAs: "steer" });
      } catch {
      }
    }
    if (!shouldBlockToolForBudget(budget, toolName, toolCount)) return void 0;
    return { block: true, reason: toolBudgetBlockedMessage(budget, toolName, toolCount) };
  });
}
function registerStructuredOutputTool(pi, structured) {
  const terminalState = structured.terminalState ??= { captured: false };
  const required = structured.acceptanceReport === "required";
  const parameters = createStructuredOutputToolParameters(structured.schema, { acceptanceReport: structured.acceptanceReport });
  const registerTool = pi.registerTool;
  registerTool({
    name: "structured_output",
    ...MODEL_ONLY_TOOL,
    label: "Structured Output",
    description: "Submit the required final structured output for this subagent step. This terminates the step.",
    parameters,
    prepareArguments: (args) => prepareStructuredOutputArguments(structured.schema, args),
    async execute(_id, params) {
      const validation = await validateStructuredOutputValue(structured.schema, params.value);
      if (validation.status === "invalid") {
        throw new Error(`Structured output validation failed: ${validation.message}`);
      }
      if (required && params.acceptanceReport === void 0) {
        throw new Error(MISSING_STRUCTURED_ACCEPTANCE_REPORT_ERROR);
      }
      if (required && params.acceptanceReport !== void 0) {
        const acceptanceValidation = validateAcceptanceReport(params.acceptanceReport, "acceptanceReport");
        if (!acceptanceValidation.report) {
          throw new Error(`Invalid structured output acceptance report: ${acceptanceValidation.errors.join("; ")}`);
        }
      }
      structured.capture(params.value, structured.acceptanceReport ? params.acceptanceReport : void 0);
      terminalState.captured = true;
      return {
        content: [{ type: "text", text: "Structured output captured." }],
        details: {},
        terminate: true
      };
    }
  });
}
function registerSubagentPromptRuntime(pi, config, drainObservation) {
  if (!config) return;
  registerRuntimeExtensionAcknowledgements(pi, config.runtimeAcknowledgements);
  registerPermissionGate(pi, config.permissions, config.childWatchdog);
  registerToolBudget(pi, config.toolBudget);
  if (config.structuredOutput && !config.structuredOutput.terminalState) config.structuredOutput.terminalState = { captured: false };
  registerChildWatchdog(pi, config.childWatchdog, config.watchdogStatus, config.structuredOutput?.terminalState);
  const requestedWatchdogDiff = config.requiredTools?.includes(WATCHDOG_DIFF_TOOL_NAME);
  const reviewerLaunchBaseline = requestedWatchdogDiff && config.cwd ? captureWatchdogDiffBaseline(config.cwd) : void 0;
  if (requestedWatchdogDiff && typeof pi.registerTool === "function") {
    pi.registerTool(createWatchdogDiffTool(reviewerLaunchBaseline, { workingTreeAtLaunch: true }));
  }
  const waitState = config.runtimeState ?? {
    baseCwd: "",
    currentSessionId: null,
    asyncJobs: /* @__PURE__ */ new Map(),
    foregroundRuns: /* @__PURE__ */ new Map(),
    foregroundControls: /* @__PURE__ */ new Map(),
    lastForegroundControlId: null,
    cleanupTimers: /* @__PURE__ */ new Map(),
    lastUiContext: null,
    poller: null,
    completionSeen: /* @__PURE__ */ new Map(),
    watcher: null,
    watcherRestartTimer: null,
    resultFileCoalescer: { schedule: () => false, clear: () => {
    } }
  };
  const nestedRootRunId = inheritedNestedRouteOf(config)?.rootRunId;
  setWaitToolName(config.waitTool.name ?? DEFAULT_WAIT_TOOL_NAME);
  if (typeof pi.registerTool === "function") registerWaitTool(pi, waitState, config.waitTool.enabled, void 0, config.waitTool.defaultTimeoutMs, { nestedRootRunId }, () => config.hasPendingSupervisorRequest?.() === true);
  const supervisorMetadata = childSupervisorMetadata(config);
  let nativeSupervisorClientRegistered = false;
  const registerNativeSupervisorClientOnce = () => {
    if (nativeSupervisorClientRegistered) return;
    nativeSupervisorClientRegistered = true;
    registerNativeSupervisorClient(pi, supervisorMetadata);
  };
  const onRuntimeEvent = pi.on;
  onRuntimeEvent("session_start", (_event, ctx) => {
    const sessionManager = ctx?.sessionManager;
    waitState.currentSessionId = sessionManager ? resolveCurrentSessionId(sessionManager) : null;
    waitState.supervisorOwnerSessionId = sessionManager?.getSessionId() || null;
    registerNativeSupervisorClientOnce();
  });
  onRuntimeEvent("agent_start", () => {
    if (!config.requiredTools) return;
    const diagnostic = evaluateChildToolDiagnostic(config, pi.getAllTools().map((tool) => tool.name));
    config.toolDiagnostic?.(diagnostic);
    if (diagnostic) throw new Error(formatChildToolDiagnostic(diagnostic));
  });
  onRuntimeEvent("agent_end", async (_event, ctx) => {
    if (ctx?.hasUI === true) drainObservation?.deny();
    if (drainObservation) {
      try {
        if (ctx?.sessionManager?.getSessionFile() !== waitState.currentSessionId) drainObservation.deny();
      } catch {
        drainObservation.deny();
      }
    }
    config.holdFinalDrain?.(true);
    try {
      await drainOutstandingWork({ state: waitState, events: pi.events, nestedRootRunId, hasPendingSupervisorRequest: config.hasPendingSupervisorRequest }, drainObservation);
    } finally {
      config.holdFinalDrain?.(false);
    }
  });
  if (config.structuredOutput) registerStructuredOutputTool(pi, config.structuredOutput);
  onRuntimeEvent("before_provider_request", (event, ctx) => rewriteForkCacheProviderRequest(event, ctx, config.forkCacheKey));
  let inherited;
  const readInherited = (ctx) => {
    const header = ctx?.sessionManager?.getHeader();
    if (!header) return void 0;
    if (inherited?.session !== header.id) {
      const forkedAt = Date.parse(header.timestamp);
      const messages = Number.isFinite(forkedAt) ? ctx.sessionManager.buildSessionProjection().messages : [];
      inherited = { session: header.id, forkedAt, system: systemMessagesBefore(messages, forkedAt), model: modelBefore(messages, forkedAt) };
    }
    return Number.isFinite(inherited.forkedAt) ? inherited : void 0;
  };
  const boundary = rewritesChildPrompt(config) ? childBoundary({ fanoutChild: config.fanoutChild, structuredOutput: Boolean(config.structuredOutput) }) : void 0;
  if (config.forkCacheKey) onRuntimeEvent("before_provider_headers", (event, ctx) => {
    applyForkSessionAffinity(event?.headers, ctx?.model, config.parentSessionId, readInherited(ctx)?.model);
  });
  onRuntimeEvent("context_with_system", (event, ctx) => {
    if (!event || typeof event !== "object" || !("messages" in event) || !Array.isArray(event.messages)) return void 0;
    const fork = config.forkCacheKey ? readInherited(ctx) : void 0;
    const stripped = stripParentOnlySubagentMessages(event.messages, {
      sanitizeToolIds: !COMPOSITE_TOOL_ID_APIS.has(ctx?.model?.api ?? ""),
      // Providers that reuse the Codex Responses wire under their own api id (e.g. cliproxyapi-codex-responses) split call_id|item_id the same way.
      preserveBoundedCompositeToolIds: ctx?.model?.api?.endsWith("-codex-responses") === true,
      preserveFanoutToolHistory: config.fanoutChild,
      ...fork ? { inheritedBefore: fork.forkedAt } : {}
    });
    const messages = fork ? projectForkRequest(stripped, fork.system, fork.forkedAt, { boundary }) : stripped;
    return messages === event.messages ? void 0 : { messages };
  });
  const routingName = config.intercomSessionName;
  let intercomIdClaimed = false;
  if (routingName) {
    pi.events.on(INTERCOM_SESSION_IDENTITY_EVENT, (request) => {
      if (!request || typeof request !== "object" || !("version" in request) || request.version !== 1 || !("claim" in request) || typeof request.claim !== "function") return;
      request.claim(routingName);
      intercomIdClaimed = true;
    });
  }
  onRuntimeEvent("before_agent_start", async (event) => {
    if (!event || typeof event !== "object" || !("systemPrompt" in event) || typeof event.systemPrompt !== "string") return void 0;
    registerNativeSupervisorClientOnce();
    const childSessionName = intercomIdClaimed ? config.sessionName || routingName : routingName || config.sessionName;
    if (childSessionName && typeof pi.setSessionName === "function") {
      pi.setSessionName(childSessionName);
    }
    if (!rewritesChildPrompt(config)) return;
    filterChildPromptOptions(event.systemPromptOptions, {
      inheritProjectContext: config.inheritProjectContext ?? true,
      inheritGlobalContext: config.inheritGlobalContext ?? true,
      inheritSkills: config.inheritSkills ?? true
    });
  });
}

export {
  projectRuntimeAcknowledgedExtensions,
  formatChildToolDiagnostic,
  rewriteSubagentPrompt,
  registerSubagentPromptBoundary,
  registerSubagentPromptRuntime
};
