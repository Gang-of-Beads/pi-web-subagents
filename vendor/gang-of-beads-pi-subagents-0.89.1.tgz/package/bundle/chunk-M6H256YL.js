// package.json
var package_default = {
  name: "pi-subagents",
  version: "0.89.1",
  private: true,
  description: "Pi extension for single-agent delegation and scripted multi-agent workflows",
  author: "Nico Bailon",
  license: "MIT",
  type: "module",
  exports: {
    ".": "./index.ts",
    "./background-work": "./src/api/background-work.ts",
    "./external-job-provider": "./src/api/external-job-provider.ts",
    "./external-runs": "./src/api/external-runs.ts",
    "./agents": "./src/api/agents.ts",
    "./inspectors": "./src/api/inspectors.ts",
    "./delegation": "./src/api/delegation.ts",
    "./capability-ceiling": "./src/api/capability-ceiling.ts",
    "./workflow-resources": "./src/api/workflow-resources.ts",
    "./required-child-extensions": "./src/api/required-child-extensions.ts",
    "./preflight": "./src/api/preflight.ts",
    "./control-channel": "./src/api/control-channel.ts",
    "./intercom-bridge": "./src/api/intercom-bridge.ts",
    "./child-tool-plan": "./src/api/child-tool-plan.ts",
    "./shared-types": "./src/api/shared-types.ts",
    "./project-panes": "./src/api/project-panes.ts"
  },
  repository: {
    type: "git",
    url: "git+https://github.com/Gang-of-Beads/pi-subagents.git"
  },
  homepage: "https://github.com/Gang-of-Beads/pi-subagents#readme",
  bugs: {
    url: "https://github.com/Gang-of-Beads/pi-subagents/issues"
  },
  keywords: [
    "pi-package",
    "pi",
    "pi-coding-agent",
    "extension",
    "subagents",
    "ai",
    "agents",
    "cli"
  ],
  bin: {
    "pi-subagents": "install.mjs"
  },
  files: [
    "index.ts",
    "src/**/*.ts",
    "*.mjs",
    "workflow-script-worker.cjs",
    "workflow-script-process.cjs",
    "agents/",
    "skills/**/*",
    "prompts/**/*",
    "docs/**/*",
    "README.md",
    "CHANGELOG.md"
  ],
  scripts: {
    "build:pkg": "node scripts/build-package.mjs",
    "pack:pkg": "npm run build:pkg && npm pack ./dist-pkg",
    typecheck: "tsc --noEmit",
    test: "npm run test:unit",
    "test:unit": "node --experimental-strip-types --import ./test/support/isolated-temp-root.mjs --test test/unit/*.test.ts",
    "test:integration": "node --experimental-strip-types --import ./test/support/register-loader.mjs --test test/integration/*.test.ts",
    "test:smoke:tool-activation": "node --experimental-strip-types --test test/smoke/tool-activation.test.ts",
    "test:all": "npm run test:unit && npm run test:integration"
  },
  pi: {
    extensions: [
      "./index.ts"
    ],
    skills: [
      "./skills"
    ],
    prompts: [
      "./prompts"
    ]
  },
  peerDependencies: {
    "@earendil-works/pi-agent-core": "*",
    "@earendil-works/pi-ai": ">=1.2.0",
    "@earendil-works/pi-coding-agent": "*",
    "@earendil-works/pi-tui": "*",
    typebox: "*"
  },
  peerDependenciesMeta: {
    "@earendil-works/pi-agent-core": {
      optional: true
    },
    "@earendil-works/pi-ai": {
      optional: true
    },
    "@earendil-works/pi-coding-agent": {
      optional: true
    },
    "@earendil-works/pi-tui": {
      optional: true
    },
    typebox: {
      optional: true
    }
  },
  dependencies: {
    "@js-temporal/polyfill": "0.5.1",
    acorn: "8.18.0",
    jiti: "2.7.0",
    undici: "8.12.4",
    yaml: "2.8.3"
  },
  devDependencies: {
    "@earendil-works/pi-agent-core": "1.2.0",
    "@earendil-works/pi-ai": "1.2.0",
    "@earendil-works/pi-coding-agent": "1.2.0",
    "@earendil-works/pi-tui": "1.2.0",
    "@oxlint/plugins": "1.80.0",
    "@types/node": "24.13.3",
    esbuild: "0.28.2",
    oxlint: "1.80.0",
    typebox: "1.3.27",
    typescript: "5.9.3"
  },
  overrides: {
    undici: "$undici"
  }
};

export {
  package_default
};
